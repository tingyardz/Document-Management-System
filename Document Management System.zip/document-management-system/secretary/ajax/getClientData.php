<?php
    require_once('../../connection.php');
    $id = $_POST['id'];
    $sql = "SELECT  `First_Name`, `Middle_Name`, `Last_Name`, `Age`, `Citizenship`, `Legal_Status`, `Address`, `Valid_Id`, `Id_Exp`, `Client_Data`, `Date_Added`, `Time_Added` FROM `client_data_tbl` WHERE `Id` = '$id'";
    $query = $connect->query($sql) or die($connect->error);
    $row = $query->fetch_assoc();
    echo json_encode($row);
?>
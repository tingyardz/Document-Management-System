<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Secretary"){
        header("Location:../index.php");
    }

    $userId = $_SESSION['dms-login-Id'];
    $sql = "SELECT * FROM `user_tbl` WHERE `Id`='$userId'";
    $query = $query = $connect->query($sql) or die($connect->error);
    $row = $query->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secretary | DMS</title>
    <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/jquery.min.js"></script>
    <style>
        .menu-tab{
            color: rgb(150,150,150);
        }
        .menu-tab:hover{
            color: white;
        }
        #account-settings-tab{
            background-color: rgba(0,0,0,0.3);
            color: white;
        }
    </style>
</head>
<body class="sb-nav-fixed">

    <?php require_once("top-bar.php"); ?>

    <div id="layoutSidenav">

        <!-- Navigation Bar -->
        <?php require_once('navbar.php'); ?>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Account Settings</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Home</li>
                        <li class="breadcrumb-item active">Account Settings</li>
                    </ol>

                    <!-- Alert Message -->
                    <div id="processing-message-alert" class="alert d-none text-center" role="alert"></div>

                    <div class="row bg-light py-2">
                        <div class="card-body">
                            <form action="../form-process.php" method="POST">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mb-md-0">
                                            <input class="form-control" id="inputFirstName" type="text" name="firstname" placeholder="Enter your first name" value="<?php echo $row['First_Name']; ?>"/>
                                            <label for="inputFirstName">First Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input class="form-control" id="inputLastName" type="text" name="lastname" placeholder="Enter your last name" value="<?php echo $row['Last_Name']; ?>"/>
                                            <label for="inputLastName">Last Name</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mb-md-0">
                                            <input class="form-control" id="inputUserName" type="text" name="username" placeholder="Enter your username" value="<?php echo $row['User_Name']; ?>"/>
                                            <label for="inputUserName">Username</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <select class="form-select" name="usertype" id="usertype">
                                                <option value="Secretary" selected>Secretary</option>
                                            </select>
                                            <label for="usertype">User Type</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mb-md-0">
                                            <input class="form-control" id="inputPassword" type="password" name="password" placeholder="Create a password" value="<?php echo $row['Password']; ?>"/>
                                            <label for="inputPassword">Password</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mb-md-0">
                                            <input class="form-control" id="inputPasswordConfirm" type="password" placeholder="Confirm password" value="<?php echo $row['Password']; ?>"/>
                                            <label for="inputPasswordConfirm">Confirm Password</label>
                                        </div>
                                    </div>
                                </div>

                                <div id="message-alert" style="display:none;" class="bg-danger text-center text-light p-2"><h6 class="m-0">Please recheck your password!</h6></div>


                                <div class="mt-4">
                                    <div class="d-grid"><center><button onclick="return validateForm()" class="btn btn-primary w-50" type="submit" name="update-account">Update Account</button></center></div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </main>
        </div>

    </div>

    <!-- Javascript -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/account-settings.js"></script>
</body>
</html>
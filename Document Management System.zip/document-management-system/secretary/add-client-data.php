<?php
    require_once('../connection.php');
    try {
        $tempId = $_GET['Id'];
        $sql = "SELECT * FROM `doc_templates_tbl` 
                INNER JOIN `client_data_structure_tbl` ON `doc_templates_tbl`.`Title_Id` =  `client_data_structure_tbl`.`Title_Id`
                JOIN `documents_title_tbl` ON `doc_templates_tbl`.`Title_Id` =  `documents_title_tbl`.`Id`
                WHERE `doc_templates_tbl`.`Id` = '$tempId' ";
        $query = $connect->query($sql) or die($connect->error);
        $row = $query->fetch_assoc();
        $titleId = $row['Title_Id'];
        $title = $row['Title'];
        $clientForm = $row['Client_Form'];
    } catch (\Throwable $th) {
        echo "<script>window.close();</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Form</title>
    <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="ckeditor/ckeditor.js"></script>
    <style>
        /* body{
            background-color: rgb(233,235,238);
        }
        .wrapper{
            padding: 20px;
            box-shadow: 5px 6px 10px black;
            background-color: white;
        } */

        body{
            background-color: rgb(233,235,238);
        }
        #search-result li{
            list-style:none;
            cursor:pointer;
            overflow: hidden;
            height: 40px;
            position:relative;
        }
        #search-result li:hover{
            background-color: rgb(240,240,240);
        }
        #search-result ul{
            padding:0;
            margin:0;
        }
    </style>
</head>
<body>
    <div class="container-fluid">

        <div class="wrapper border p-4 bg-light" style="width:90%;margin: 30px auto;">

            <div>
                <h1 class="mb-3 text-center"><span><?php echo $title; ?></span></h1>
            </div>

            <div class="mt-3">
                <form action="../form-process.php" method="POST">

                    <div class="d-none">
                        <input type="text" name="title-id" value="<?php echo $titleId; ?>">
                        <input type="text" name="temp-id" value="<?php echo $tempId; ?>">
                    </div>

                    <?php echo $clientForm; ?>

                    <div class="py-3">
                        <button id="save-data" class="btn btn-primary w-100" name="save-data" onclick="validate()">Save Data</button>
                    </div>

                </form>
            </div>

        </div>

    </div>
    
    <!-- Javascript -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            //ckeditor
            var textfields = $('textarea');
            for (let index = 0; index < textfields.length; index++) {
                var textField_Id = textfields[index].id;
                CKEDITOR.replace(textField_Id);
            }
        });


        function validate(){
            var permission = confirm("Are you sure to save these data?");
            if(!permission){
                return false;
            }
        }
    </script>
</body>
</html>
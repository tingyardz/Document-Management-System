<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Secretary" && $_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }
    $sql = "SELECT *, `documents_tbl`.`Id` AS `document_id`, `documents_tbl`.`Status` AS `document_status` FROM `documents_tbl`
            INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id`
            INNER JOIN `doc_templates_tbl` ON `doc_templates_tbl`.`Id` = `documents_tbl`.`Temp_Id`
            INNER JOIN `documents_title_tbl` ON `documents_title_tbl`.`Id` = `documents_tbl`.`Title_Id`";
    $query = $connect->query($sql) or die($connect->error);
    $total = $query->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $_SESSION['dms-login-User_Type']; ?> | DMS</title>
        <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="../bootstrap/css/simple-datatables@latest.css">
        <link rel="stylesheet" href="../bootstrap/css/table.style.css">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/all.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="ckeditor/ckeditor.js"></script>
        <link rel="stylesheet" href="css/all-documents.css">

   </head>
    <body class="sb-nav-fixed">

        <?php require_once("top-bar.php"); ?>

        <div id="layoutSidenav">

            <!-- Navigation Bar -->
            <?php 
                switch ($_SESSION['dms-login-User_Type']) {
                    case 'Secretary':
                        require_once('navbar.php');
                        break;
                    case 'Admin':
                        require_once('navbar-admin.php');
                        break;
                    
                    default:
                        # code...
                        break;
                }
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">All Documents</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home</li>
                            <li class="breadcrumb-item active">Documents Today</li>
                        </ol>

                        <!-- Alert -->
                        <div id="processing-message-alert" class="alert d-none text-center" role="alert"></div>

                        <div class="row bg-light mb-5">
                            <div class="card">
                                <div class="card-header">
                                    <div class="p-1" style="display:inline-block;"><i class="fas fa-table me-1"></i>Documents List</div>
                                </div>
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>Doc No.</th>
                                                <th>Date</th>
                                                <th>Document Name</th>
                                                <th>Client Name</th>
                                                <th>Produced By</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($total){
                                                    while ($row = $query->fetch_assoc()) {
                                                        $title = strtolower($row['Title']);
                                                        $viewURL = str_replace(' ','-',$title).".php";
                                            ?>

                                            <tr>
                                                <td><?php echo $row['Doc_No']; ?></td>
                                                <td><?php echo $row['Date_Added']; ?></td>
                                                <td><?php echo $row['Title']; ?></td>
                                                <td><?php echo $row['First_Name'].' '.$row['Middle_Name'].' '.$row['Last_Name']; ?></td>
                                                <td><?php echo $row['Produced_By']; ?></td>
                                                <?php
                                                    if($row['document_status'] == '1'){
                                                        echo "<td class=\"status text-success\">PAID</td>";
                                                    }
                                                    elseif ($row['document_status'] == '0') {
                                                        echo "<td class=\"status text-danger\">UNPAID</td>";
                                                    }
                                                ?>
                                                <td>
                                                    <button onclick="createPopupWin('<?php echo 'view/'.$viewURL.'?Id='.$row['document_id']; ?>')">View</button>
                                                    <button onclick="createPopupWin('<?php echo 'update-client-data.php?doc_id='.$row['document_id']; ?>')">Update</button>
                                                    <button onclick="deleteClientData(<?php echo $row['document_id']; ?>)">Delete</button>
                                                </td>
                                            </tr>

                                            <?php
                                                    }
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                        </div>

                    </div>
                </main>
            </div>
        </div>

        <!-- Javascript -->
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="../bootstrap/js/datatables-simple-demo.js"></script>
        <script src="../bootstrap/js/simple-datatables@latest.js"></script>
        <script src="js/all-documents.js"></script>
    </body>
</html>

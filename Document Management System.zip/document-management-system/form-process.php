<?php
    require_once('connection.php');
    require_once('methods.php');
    $method = new Methods();

    if(isset($_POST['update-data'])){
        try {
            $doc_id = $_POST['doc-id'];
            $clientData_id = $_POST['client-data-id'];
    
            $fullName = $_POST['basic-input'][0]." ".$_POST['basic-input'][1]." ".$_POST['basic-input'][2];
            $affiantFirstName = $_POST['basic-input'][0];
            $affiantMiddleName = $_POST['basic-input'][1];
            $affiantLastName = $_POST['basic-input'][2];
            $affiantAge = $_POST['basic-input'][3];
            $affiantCitizenship = $_POST['basic-input'][4];
            $affiantLegalStatus = $_POST['basic-input'][5];
            $affiantAddress = $_POST['basic-input'][6];
            $affiantValidId = $_POST['basic-input'][7];
            $affiantIdExpDate = $_POST['basic-input'][8];
            $clientData = implode('->', $_POST['clientData']);
            $docNo = $_POST['doc-no'];
            $pageNo = $_POST['page-no'];
            $bookNo = $_POST['book-no'];
            $seriesOf = $_POST['series-of'];
    
            date_default_timezone_set("Asia/Kuala_Lumpur");
            $dateAdded = date("Y/m/d");
            $timeAdded = date("h:i:sa");
    
            session_start();
            $producedBy = $_SESSION['dms-login-First_Name'].' '.$_SESSION['dms-login-Last_Name'];
    
            //update client data
            $sql = "UPDATE `client_data_tbl` SET `First_Name`='$affiantFirstName',`Middle_Name`='$affiantMiddleName',`Last_Name`='$affiantLastName',`Age`='$affiantAge',`Citizenship`='$affiantCitizenship',`Legal_Status`='$affiantLegalStatus',`Address`='$affiantAddress',`Valid_Id`='$affiantValidId',`Id_Exp`='$affiantIdExpDate',`Client_Data`='$clientData',`Date_Added`='$dateAdded',`Time_Added`='$timeAdded' WHERE `Id` = '$clientData_id'";
            $query = $connect->query($sql) or die($connect->error);
    
            //update document tbl
            $sql = "UPDATE `documents_tbl` SET `Doc_No`='$docNo',`Page_No`='$pageNo',`Book_No`='$bookNo',`Series_of`='$seriesOf',`Produced_By`='$producedBy',`Client_Name`='$fullName' WHERE `Id` = '$doc_id'";
            $query = $connect->query($sql) or die($connect->error);

            //adding client name into the list
            $sql = "SELECT * FROM `client_nameList_tbl` WHERE `Full_Name` = '$fullName'";
            $query = $connect->query($sql) or die($connect->error);
            if($query->num_rows == 0){
                $sql = "INSERT INTO `client_nameList_tbl`(`Full_Name`) VALUE ('$fullName')";
                $query = $connect->query($sql) or die($connect->error);
            }
    
            echo "<script>window.alert('Successfully Updated!');window.close();</script>";
            exit();
        } catch (\Throwable $th) {
            $prevPage = $_SERVER['HTTP_REFERER'];
            echo "<script>window.alert('There was a problem found!');window.location.href='$prevPage';</script>";
            exit();
        }
    }
    elseif(isset($_POST['save-data'])){
        try {
            $titleId = $_POST['title-id'];
            $tempId = $_POST['temp-id'];

            $fullName = $_POST['basic-input'][0].' '.$_POST['basic-input'][1].' '.$_POST['basic-input'][2];
            $affiantFirstName = $_POST['basic-input'][0];
            $affiantMiddleName = $_POST['basic-input'][1];
            $affiantLastName = $_POST['basic-input'][2];
            $affiantAge = $_POST['basic-input'][3];
            $affiantCitizenship = $_POST['basic-input'][4];
            $affiantLegalStatus = $_POST['basic-input'][5];
            $affiantAddress = $_POST['basic-input'][6];
            $affiantValidId = $_POST['basic-input'][7];
            $affiantIdExpDate = $_POST['basic-input'][8];
            $clientData = implode('->', $_POST['clientData']);
            $docNo = $_POST['doc-no'];
            $pageNo = $_POST['page-no'];
            $bookNo = $_POST['book-no'];
            $seriesOf = $_POST['series-of'];
    
            date_default_timezone_set("Asia/Kuala_Lumpur");
            $dateAdded = date("Y/m/d");
            $timeAdded = date("h:i:sa");

            session_start();
            $producedBy = $_SESSION['dms-login-First_Name'].' '.$_SESSION['dms-login-Last_Name'];
    
            //insert data
            $sql = "INSERT INTO `client_data_tbl`(`First_Name`, `Middle_Name`, `Last_Name`, `Age`, `Citizenship`, `Legal_Status`, `Address`, `Valid_Id`, `Id_Exp`, `Client_Data`, `Date_Added`, `Time_Added`) 
                    VALUES ('$affiantFirstName','$affiantMiddleName','$affiantLastName','$affiantAge','$affiantCitizenship','$affiantLegalStatus','$affiantAddress', '$affiantValidId', '$affiantIdExpDate', '$clientData','$dateAdded','$timeAdded')";
            $query = $connect->query($sql) or die($connect->error);
    
            //get id
            $sql = "SELECT `Id` FROM `client_data_tbl` WHERE `Date_Added` = '$dateAdded' AND `Time_Added` = '$timeAdded'";
            $query = $connect->query($sql) or die($connect->error);
            $row = $query->fetch_assoc();
            $dataId = $row['Id'];
    
            //insert into documents table
            $sql = "INSERT INTO `documents_tbl`(`Title_Id`, `Temp_Id`, `Client_Data_Id`, `Status`, `Doc_No`, `Page_No`, `Book_No`, `Series_of`, `Produced_By`, `Client_Name`) 
                    VALUES ('$titleId','$tempId','$dataId','0','$docNo','$pageNo','$bookNo','$seriesOf','$producedBy', '$fullName')";
            $query = $connect->query($sql) or die($connect->error);

            //adding client name into the list
            $sql = "SELECT * FROM `client_nameList_tbl` WHERE `Full_Name` = '$fullName'";
            $query = $connect->query($sql) or die($connect->error);
            if($query->num_rows == 0){
                $sql = "INSERT INTO `client_nameList_tbl`(`Full_Name`) VALUE ('$fullName')";
                $query = $connect->query($sql) or die($connect->error);
            }

            echo "<script>window.alert('Successfully Saved!');window.close();</script>";
            exit();
        } catch (\Throwable $th) {
            $prevPage = $_SERVER['HTTP_REFERER'];
            echo "<script>window.alert('There was a problem found!');window.location.href='$prevPage';</script>";
            // echo $th->getMessage();
            exit();
        }

    }
    elseif(isset($_POST['update-client-data'])){
        session_start();
        $clientId = $_POST['clientId'];
        $clientName = $_POST['clientData'][0];
        $clientData = implode('->', $_POST['clientData']);
        $docNo = $_POST['doc-no'];
        $pageNo = $_POST['page-no'];
        $bookNo = $_POST['book-no'];
        $seriesOf = $_POST['series-of'];
        $prevLocation = $_SERVER['HTTP_REFERER'];
        $secretaryName = $_SESSION['dms-login-First_Name'].' '.$_SESSION['dms-login-Last_Name'];
        $date = $_SESSION['date-today'];
        $status = "UNPAID";
        try {
            $sql = "UPDATE `client_data_tbl` SET `Client_Name`='$clientName',`Client_Data`='$clientData',`Doc_No`='$docNo',`Page_No`='$pageNo',`Book_No`='$bookNo',`Series_of`='$seriesOf',`Date`='$date',`Secretary_Name`='$secretaryName',`Status`='$status' WHERE `ClientData_Id` = '$clientId'";
            $query = $connect->query($sql) or die($connect->error);
            echo "<script>alert('Successfully Updated!');window.close();</script>";
        } catch (\Throwable $th) {
            echo "<script>alert('There was a problem found! Please try again later.');window.location.href='$prevLocation';</script>";
        }
    }
    elseif(isset($_POST['update-template'])){
        $id = $_POST['temp-id'];
        $header = implode('->', $_POST['header']);
        $body = implode('->', $_POST['body']);
        $footer = implode('->', $_POST['footer']);
        $prevLocation = $_SERVER['HTTP_REFERER'];
        try {
            $sql = "UPDATE `doc_templates_tbl` 
                    SET `Header`='$header',`Body`='$body',`Footer`='$footer' WHERE `Id` = '$id'";
            $query = $connect->query($sql) or die($connect->error);
            echo "<script>alert('Successfully Updated!');window.close();</script>";
        } catch (\Throwable $th) {
            echo "<script>alert('There was a problem found! Please try again later.');window.location.href='$prevLocation';</script>";
        }

    }
    elseif(isset($_POST['save-client-data'])){
        session_start();
        $templateId = $_POST['temp-id'];
        $title = $_POST['title'];
        $clientName = $_POST['clientData'][0];
        $clientData = implode('->', $_POST['clientData']);
        $docNo = $_POST['doc-no'];
        $pageNo = $_POST['page-no'];
        $bookNo = $_POST['book-no'];
        $seriesOf = $_POST['series-of'];
        $prevLocation = $_SERVER['HTTP_REFERER'];
        $secretaryName = $_SESSION['dms-login-First_Name'].' '.$_SESSION['dms-login-Last_Name'];
        $date = $_SESSION['date-today'];
        $status = "UNPAID";
        try {
            $sql0 = "SELECT `Price` FROM `price_tbl` WHERE `Temp_Id` = '$templateId'";
            $query0 = $connect->query($sql0) or die($connect->error);
            $row0 = $query0->fetch_assoc();
            $amount = $row0['Price'];

            $sql = "INSERT INTO `client_data_tbl`(`Amount`, `Title`, `Client_Name`, `Client_Data`, `Doc_No`, `Page_No`, `Book_No`, `Series_of`, `Date`, `Secretary_Name`, `Status`, `Template_Id`) 
                    VALUES ('$amount', '$title','$clientName','$clientData', '$docNo', '$pageNo', '$bookNo', '$seriesOf', '$date', '$secretaryName', '$status', '$templateId')";
            $query = $connect->query($sql) or die($connect->error);
            echo "<script>alert('Successfully Saved!');window.close();</script>";
        } catch (\Throwable $th) {
            echo "<script>alert('There was a problem found! Please try again later.');window.location.href='$prevLocation';</script>";
        }
    }
    elseif(isset($_POST['save-template'])){
        if(isset($_POST['title-id'])){
            $titleId = $_POST['title-id'];
            $header = implode('->', $_POST['header']);
            $body = implode('->', $_POST['body']);
            $footer = implode('->', $_POST['footer']);
            $prevLocation = $_SERVER['HTTP_REFERER'];

            try {
                //insert to template table
                $sql = "INSERT INTO `doc_templates_tbl`(`Title_Id`, `Header`, `Body`, `Footer`, `Status`) 
                        VALUES ('$titleId','$header','$body','$footer', '0')";
                $query = $connect->query($sql) or die($connect->error);

                session_start();
                $_SESSION['processing-message-alert'] = array("New template has been added.","alert-success");
                header("Location:$prevLocation");
            } catch (\Throwable $th) {
                session_start();
                $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
                header("Location:$prevLocation");
            }
        }else {
            $prevLocation = $_SERVER['HTTP_REFERER'];
            header("Location:$prevLocation");
        }
    }
    elseif(isset($_POST['create-template'])){
        $title = strtoupper($_POST['title']);
        $header = json_encode($_POST['header']);
        $body = json_encode($_POST['body']);
        $footer = json_encode($_POST['footer']);
        $status = "Disable";
        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            $sql = "INSERT INTO `templates_tbl`(`Title`, `Header`, `Body`, `Footer`, `Status`) 
                    VALUES ('$title', '$header', '$body', '$footer', '$status')";
            $query = $connect->query($sql) or die($connect->error);
            session_start();
            $_SESSION['processing-message-alert'] = array("New template has been added.","alert-success");
            header("Location:$prevLocation");
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
        }
    }
    elseif(isset($_POST['create-template-old'])){
        $header = $method->singleQuote($_POST['header']);
        $title = $method->singleQuote($_POST['title']);
        $bodyHeader = $method->singleQuote($_POST['body-header']);
        $bodyFooter = $method->singleQuote($_POST['body-footer']);
        $footer = $method->singleQuote($_POST['footer']);
        $status = "Disable";
        $prevLocation = $_SERVER['HTTP_REFERER'];
        try {
            $sql = "INSERT INTO `templates_tbl`(`Header`, `Title`, `Body_Header`, `Body_Footer`, `Footer`, `Status`) 
                    VALUES ('$header','$title','$bodyHeader','$bodyFooter','$footer','$status')";
            $query = $connect->query($sql) or die($connect->error);
            session_start();
            $_SESSION['processing-message-alert'] = array("New template has been added.","alert-success");
            header("Location:$prevLocation");
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
        }
    }
    elseif(isset($_POST['create-document'])){
        session_start();
        $templateId = $_POST['template-id'];
        $header = $method->singleQuote($_POST['header']);
        $title = $method->singleQuote($_POST['title']);
        $bodyHeader = $method->singleQuote($_POST['body-header']);
        $bodyFooter = $method->singleQuote($_POST['body-footer']);
        $footer = $method->singleQuote($_POST['footer']);
        $docNo = $method->singleQuote($_POST['doc-no']);
        $pageNo = $method->singleQuote($_POST['page-no']);
        $bookNo = $method->singleQuote($_POST['book-no']);
        $seriesOf = $method->singleQuote($_POST['series-of']);
        $clientName = $method->singleQuote($_POST['client-name']);
        $secretaryName = $_SESSION['dms-login-First_Name'].' '.$_SESSION['dms-login-Last_Name'];
        $date = $_SESSION['date-today'];
        $status = "UNPAID";
        $amount = 0;

        //getting the price of this document
        $sql = "SELECT * FROM `price_tbl` WHERE `Temp_Id` = '$templateId'";
        $query = $connect->query($sql) or die($connect->error);
        $row = $query->fetch_assoc();
        if($query->num_rows > 0){
            $amount = $row['Price'];
        }
        else{
            $amount = $templateId;
        }

        $sql = "INSERT INTO `documents_tbl`(`Header`, `Title`, `Body_Header`, `Body_Footer`, `Footer`, `Doc_No`, `Page_No`, `Book_No`, `Series_of`, `Client_Name`, `Secretary_Name`, `Date`, `Status`, `Amount`) 
                VALUES ('$header','$title','$bodyHeader','$bodyFooter','$footer','$docNo','$pageNo','$bookNo','$seriesOf','$clientName','$secretaryName', '$date', '$status', '$amount')";
        $query = $connect->query($sql) or die($connect->error);

        echo "<script>alert('New document has been successfully created...');window.close();</script>";
    }
    elseif(isset($_POST['update-template-old'])){
        $id = $_POST['template-id'];
        $header = $method->singleQuote($_POST['header']);
        $title = $method->singleQuote($_POST['title']);
        $bodyHeader = $method->singleQuote($_POST['body-header']);
        $bodyFooter = $method->singleQuote($_POST['body-footer']);
        $footer = $method->singleQuote($_POST['footer']);

        $sql = "UPDATE `templates_tbl` SET `Header`='$header',`Title`='$title',`Body_Header`='$bodyHeader',`Body_Footer`='$bodyFooter',`Footer`='$footer' WHERE `Id` = '$id'";
        $query = $connect->query($sql) or die($connect->error);

        echo "<script>alert('The template has been successfully updated.');window.close()</script>";
    }
    elseif(isset($_POST['update-document'])){
        session_start();
        $documentId = $_POST['document-id'];
        $header = $method->singleQuote($_POST['header']);
        $title = $method->singleQuote($_POST['title']);
        $bodyHeader = $method->singleQuote($_POST['body-header']);
        $bodyFooter = $method->singleQuote($_POST['body-footer']);
        $footer = $method->singleQuote($_POST['footer']);
        $docNo = $method->singleQuote($_POST['doc-no']);
        $pageNo = $method->singleQuote($_POST['page-no']);
        $bookNo = $method->singleQuote($_POST['book-no']);
        $seriesOf = $method->singleQuote($_POST['series-of']);
        $clientName = $method->singleQuote($_POST['client-name']);
        $secretaryName = $_SESSION['dms-login-First_Name'].' '.$_SESSION['dms-login-Last_Name'];
        $date = $_SESSION['date-today'];
        $status = "UNPAID";

        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            $sql = "UPDATE `documents_tbl` SET `Header`='$header',`Title`='$title',`Body_Header`='$bodyHeader',`Body_Footer`='$bodyFooter',`Footer`='$footer',`Doc_No`='$docNo',`Page_No`='$pageNo',`Book_No`='$bookNo',`Series_of`='$seriesOf',`Client_Name`='$clientName',`Secretary_Name`='$secretaryName',`Date`='$date',`Status`='$status' WHERE `Id`='$documentId'";
            $query = $connect->query($sql) or die($connect->error);
            session_start();
            $_SESSION['processing-message-alert'] = array("Document has been successfully updated.","alert-success");
            header("Location:$prevLocation");
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
        }
    }
    elseif(isset($_POST['login-user'])) {
       $dateToday = $_POST['date-today'];
       $userName = $_POST['username'];
       $password = $_POST['password'];
       $sql = "SELECT * FROM `user_tbl` WHERE `User_Name`='$userName' AND `Password`='$password'";
       $query = $connect->query($sql) or die($connect->error);
       $row = $query->fetch_assoc();
       $total = $query->num_rows;
       if($total){
        session_start();
        foreach ($row as $key => $value) {
            $_SESSION['dms-login-'.$key] = $value;
        }
        $_SESSION['date-today'] = $dateToday;
        switch ($row['User_Type']) {
            case 'Secretary':
                header("Location:secretary");
                break;
            case 'Cashier':
                header("Location:cashier");
                break;
            case 'Admin':
                header("Location:admin");
                break;
        }
       }
       else {
        session_start();
        $_SESSION['dms-login'] = false;
        header("Location:index.php");
       }
    }
    elseif(isset($_POST['update-account'])) {
        session_start();
        $userId = $_SESSION['dms-login-Id'];
        $firstName = $_POST['firstname'];
        $lastName = $_POST['lastname'];
        $userName = $_POST['username'];
        $password = $_POST['password'];
        $userType = $_POST['usertype'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        $sql = "SELECT * FROM `user_tbl` WHERE `User_Name` = '$userName' AND `Password` = '$password' AND `User_Type` = '$userType'";
        $query = $connect->query($sql) or die($connect->error);
        if($query->num_rows > 0){
            session_start();
            $_SESSION['processing-message-alert'] = array("The username is already taken. Please try another one!","alert-danger");
            header("Location:$prevLocation");
        }
        else{
            $sql = "UPDATE `user_tbl` SET `First_Name`='$firstName',`Last_Name`='$lastName',`User_Name`='$userName',`Password`='$password',`User_Type`='$userType' WHERE `Id`='$userId' ";
            $query = $connect->query($sql) or die($connect->error);
            echo "
                <script>
                    alert('You have successfully updated your account.');
                    window.location.href='logout.php';
                </script>
            ";
        }

        
    }
    elseif(isset($_POST['search-doc-report'])){
        $dateFrom = $_POST['date-from'];
        $dateTo = $_POST['date-to'];
        $prevLocation = $_SERVER['HTTP_REFERER'];
        if(isset($_POST['title'])){
            $title = $_POST['title'];
            if(!empty($title)){
                $sql = "SELECT * FROM `documents_title_tbl` WHERE `Title` = '$title'";
                $query = $connect->query($sql) or die($connect->error);
                $total = $query->num_rows;
                if(!$total){
                    session_start();
                    $_SESSION['processing-message-alert'] = array("The title cannot be found!","alert-danger");
                    header("Location:$prevLocation");
                }
                else{
                    session_start();
                    $_SESSION['selected-category'] = 'title';
                    $_SESSION['data-input'] = $title;
                    $_SESSION['date-From'] = $dateFrom;
                    $_SESSION['date-To'] = $dateTo;
                    header("Location:$prevLocation");
                    exit();
                }
            }
        }
        elseif(isset($_POST['client-name'])){
            $clientName = $_POST['client-name'];
            if(!empty($clientName)){
                $sql = "SELECT * FROM `documents_tbl` WHERE `Client_Name` = '$clientName'";
                $query = $connect->query($sql) or die($connect->error);
                $total = $query->num_rows;
                if(!$total){
                    session_start();
                    $_SESSION['processing-message-alert'] = array("The client's name cannot be found!","alert-danger");
                    header("Location:$prevLocation");
                }
                else{
                    session_start();
                    $_SESSION['selected-category'] = 'client-name';
                    $_SESSION['data-input'] = $clientName;
                    $_SESSION['date-From'] = $dateFrom;
                    $_SESSION['date-To'] = $dateTo;
                    header("Location:$prevLocation");
                    exit();
                }
            }
        }
        else{
            session_start();
            unset($_SESSION['selected-category']);
            unset($_SESSION['data-input']);
            $_SESSION['date-From'] = $dateFrom;
            $_SESSION['date-To'] = $dateTo;
            header("Location:$prevLocation");
            exit();
        }




        // $clientName = $_POST['client-name'];
        // $dateFrom = $_POST['date-from'];
        // $dateTo = $_POST['date-to'];
        // $prevLocation = $_SERVER['HTTP_REFERER'];

        // if(strlen($clientName) > 0){
        //     $sql = "SELECT * FROM `documents_tbl` WHERE `Client_Name`='$clientName'";
        //     $query = $connect->query($sql) or die($connect->error);
        //     $total = $query->num_rows;
        //     if(!$total){
        //         session_start();
        //         $_SESSION['processing-message-alert'] = array("The client's name cannot be found!","alert-danger");
        //         header("Location:$prevLocation");
        //     }
        //     else{
        //         session_start();
        //         $_SESSION['report-search-client-name'] = $clientName;
        //         $_SESSION['date-From'] = $dateFrom;
        //         $_SESSION['date-To'] = $dateTo;
        //         header("Location:secretary/reports.php");
        //         exit();
        //     }
        // }
        // else{
        //     session_start();
        //     if(isset($_SESSION['report-search-client-name'])){
        //         unset($_SESSION['report-search-client-name']);
        //     }
        //     $_SESSION['date-From'] = $dateFrom;
        //     $_SESSION['date-To'] = $dateTo;
        //     header("Location:secretary/reports.php");
        //     exit();
        // }
    }
    elseif (isset($_POST['save-sub-doc'])) {
        $subDocId = $_POST['subDocId'];
        $title = $_POST['sub-doc-title'];
        $file = $_FILES['file'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        //get all the information of the file
        $file_name = $_FILES['file']['name'];
        $file_type = $_FILES['file']['type'];
        $file_tmp_name = $_FILES['file']['tmp_name'];
        $file_error = $_FILES['file']['error'];
        $file_size = $_FILES['file']['size'];
    
        //get the extension/format of the file
        $fileName_BreakDown = explode('.', $file_name);
        $file_actual_extension = strtolower(end($fileName_BreakDown));
    
        $allowed_format = array('jpg', 'jpeg', 'png', 'pdf', 'docx', 'doc', 'ppt', 'pub');
    
        if(in_array($file_actual_extension, $allowed_format)){
    
            if($file_error === 0){
    
                if($file_size < 5000000){ //less than 5mb
    
                    $file_name_new = $title.'-'.uniqid().".".$file_actual_extension;
                    $file_destination = 'sub-Documents/'.$file_name_new;
                    move_uploaded_file($file_tmp_name, $file_destination);
                    try {
                        $sql = "INSERT INTO `subdocuments_tbl`(`Doc_Id`, `SubDocument_Name`) 
                                VALUES ('$subDocId','$file_name_new')";
                        $query = $connect->query($sql) or die($connect->error);
                        session_start();
                        $_SESSION['processing-message-alert'] = array("The file has been successfully uploaded.","alert-success");
                        header("Location:$prevLocation");
                    } catch (\Throwable $th) {
                        session_start();
                        $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
                        header("Location:$prevLocation");
                    }
                }
                else{
                    session_start();
                    $_SESSION['processing-message-alert'] = array("Your file is too large!","alert-danger");
                    header("Location:$prevLocation");
                }
            }
            else{
                session_start();
                $_SESSION['processing-message-alert'] = array("There was a problem with your file!","alert-danger");
                header("Location:$prevLocation");
            }
        }
        else{
            session_start();
            $_SESSION['processing-message-alert'] = array("The file extension which you have been uploaded is prohibited!","alert-danger");
            header("Location:$prevLocation");
        }
    }
    elseif (isset($_POST['update-sub-doc'])) {
        $subDocId = $_POST['subDocId'];
        $currentFileName = $_POST['current-FileName'];
        $title = $_POST['sub-doc-title'];
        $file = $_FILES['file'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        //get all the information of the file
        $file_name = $_FILES['file']['name'];
        $file_type = $_FILES['file']['type'];
        $file_tmp_name = $_FILES['file']['tmp_name'];
        $file_error = $_FILES['file']['error'];
        $file_size = $_FILES['file']['size'];
    
        //get the extension/format of the file
        $fileName_BreakDown = explode('.', $file_name);
        $file_actual_extension = strtolower(end($fileName_BreakDown));
    
        $allowed_format = array('jpg', 'jpeg', 'png', 'pdf', 'docx', 'doc', 'ppt', 'pub');
    
        if(in_array($file_actual_extension, $allowed_format)){
    
            if($file_error === 0){
    
                if($file_size < 5000000){ //less than 5mb
    
                    $file_name_new = $title.'-'.uniqid().".".$file_actual_extension;
                    $file_destination = 'sub-Documents/'.$file_name_new;
                    move_uploaded_file($file_tmp_name, $file_destination);
                    try {
                        $sql = "UPDATE `subdocuments_tbl` SET `SubDocument_Name`='$file_name_new' WHERE `Doc_Id`='$subDocId'";
                        $query = $connect->query($sql) or die($connect->error);
                        
                        unlink('sub-Documents/'.$currentFileName);
                        session_start();
                        $_SESSION['processing-message-alert'] = array("The file has been successfully updated.","alert-success");
                        header("Location:$prevLocation");
                        
                    } catch (\Throwable $th) {
                        session_start();
                        $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
                        header("Location:$prevLocation");
                    }
                }
                else{
                    session_start();
                    $_SESSION['processing-message-alert'] = array("Your file is too large! Please try again later.","alert-danger");
                    header("Location:$prevLocation");                    
                }
            }
            else{
                session_start();
                $_SESSION['processing-message-alert'] = array("There was a problem with your file!","alert-danger");
                header("Location:$prevLocation"); 
            }
        }
        else{
            session_start();
            $_SESSION['processing-message-alert'] = array("The file extension which you have been uploaded is prohibited!","alert-danger");
            header("Location:$prevLocation");
        }
    }
    elseif(isset($_POST['submit-single-payment'])){
        session_start();
        $documentId = $_POST['documentId'];
        $date = $_SESSION['date-today'];
        $recipientName = $_POST['recipient-name'];
        $document = $_POST['document-title'];
        $amount = $_POST['amount'];
        $discount = $_POST['discount'];
        $finalAmount = $amount - ($amount * ($discount / 100));

        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            $sql = "INSERT INTO `payment_tbl`(`Date`, `Recipient_Name`, `Document_Title`, `Original_Amount`, `Discount`, `Final_Amount`) 
                    VALUES ('$date','$recipientName','$document','$amount','$discount%','$finalAmount')";
            $query = $connect->query($sql) or die($connect->error);

            $sql = "UPDATE `documents_tbl` SET `Status`='1' WHERE `Id` = '$documentId'";
            $query = $connect->query($sql) or die($connect->error);
            $_SESSION['processing-message-alert'] = array("Payment Transaction Successful","alert-success");
            header("Location:$prevLocation");    
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");

        }


    }
    elseif(isset($_POST['submit-payment-multiple'])){
        session_start();
        $documentId = $_SESSION['selected-data-for-payment'];
        $date = $_SESSION['date-today'];
        $recipientName = $_POST['recipient-name'];
        $discount = $_POST['discount'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            foreach ($documentId as $key => $value) {
                $sql = "SELECT * FROM `documents_tbl`
                        INNER JOIN `documents_title_tbl` ON `documents_title_tbl`.`Id` = `documents_tbl`.`Title_Id`
                        JOIN `price_tbl` ON `price_tbl`.`Temp_Id` = `documents_tbl`.`Temp_Id` WHERE `documents_tbl`.`Id`='$value'";
                $query = $connect->query($sql) or die($connect->error);
                $row = $query->fetch_assoc();
                $document = $row['Title'];
                $amount = $row['Price'];
                $finalAmount = $amount - ($amount * ($discount / 100));
    
                $sql = "INSERT INTO `payment_tbl`(`Date`, `Recipient_Name`, `Document_Title`, `Original_Amount`, `Discount`, `Final_Amount`) 
                        VALUES ('$date','$recipientName','$document','$amount','$discount%','$finalAmount')";
                $query = $connect->query($sql) or die($connect->error);
    
                $sql = "UPDATE `documents_tbl` SET `Status`='1' WHERE `Id` = '$value'";
                $query = $connect->query($sql) or die($connect->error);
            }

            unset($_SESSION['selected-data-for-payment']);
            session_start();
            $_SESSION['processing-message-alert'] = array("Payment Transaction Successful","alert-success");
            header("Location:$prevLocation");
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
        }

    }
    elseif (isset($_POST['search-cashier-report'])) {
        $dateFrom = $_POST['date-from'];
        $dateTo = $_POST['date-to'];
        session_start();
        $_SESSION['date-From'] = $dateFrom;
        $_SESSION['date-To'] = $dateTo;
        header("Location:cashier/reports.php");
        exit();
    }
    elseif (isset($_POST['add-new-user'])) {
        $firstName = $_POST['first-name'];
        $lastName = $_POST['last-name'];
        $userName = $_POST['username'];
        $password = $_POST['password'];
        $userType = $_POST['user-type'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            $sql = "SELECT * FROM `user_tbl` WHERE `User_Name` = '$userName' AND `Password` = '$password' AND `User_Type` = '$userType'";
            $query = $connect->query($sql) or die($connect->error);
            if($query->num_rows > 0){
                session_start();
                $_SESSION['processing-message-alert'] = array("The username is already taken. Please try another one!","alert-danger");
                header("Location:$prevLocation");
            }
            else{
                $sql = "INSERT INTO `user_tbl`(`First_Name`, `Last_Name`, `User_Name`, `Password`, `User_Type`) 
                        VALUES ('$firstName','$lastName','$userName','$password','$userType')";
                $query = $connect->query($sql) or die($connect->error);
                session_start();
                $_SESSION['processing-message-alert'] = array("You have successfully added the new user.","alert-success");
                header("Location:$prevLocation");
            }
            
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
        }
    }
    elseif (isset($_POST['update-user'])) {
        $userId = $_POST['id'];
        $firstName = $_POST['first-name'];
        $lastName = $_POST['last-name'];
        $userName = $_POST['username'];
        $password = $_POST['password'];
        $userType = $_POST['user-type'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            $sql = "UPDATE `user_tbl` 
                SET `First_Name`='$firstName',`Last_Name`='$lastName',`User_Name`='$userName',`Password`='$password',`User_Type`='$userType' WHERE `Id` = '$userId'";
            $query = $connect->query($sql) or die($connect->error);
            session_start();
            $_SESSION['processing-message-alert'] = array("You have successfully updated the new user's data.","alert-success");
            header("Location:$prevLocation");
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
        }
    }
    elseif(isset($_POST['submit-document-price'])){
        $tempId = $_POST['temp-id'];
        $titleId = $_POST['title-id'];
        $documentTitle = $_POST['document-title'];
        $price = $_POST['price'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            //insert into the price table
            $sql = "INSERT INTO `price_tbl`(`Temp_Id`, `Title_Id`, `Price`) 
                    VALUES ('$tempId','$titleId','$price')";
            $query = $connect->query($sql) or die($connect->error);

            //update the status of this template from the templates table
            $sql_1 = "UPDATE `doc_templates_tbl` SET `Status`='1' WHERE `Id` = '$tempId'";
            $query_1 = $connect->query($sql_1) or die($connect->error);

            session_start();
            $_SESSION['processing-message-alert'] = array("Document's price has been successfully set.","alert-success");
            header("Location:$prevLocation");
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
            
        }
    }
    elseif(isset($_POST['submit-new-document-price'])){
        $id = $_POST['id'];
        $price = $_POST['price'];
        $prevLocation = $_SERVER['HTTP_REFERER'];

        try {
            //update the price table
            $sql = "UPDATE `price_tbl` SET `Price`='$price' WHERE `Id` = '$id'";
            $query = $connect->query($sql) or die($connect->error);

            session_start();
            $_SESSION['processing-message-alert'] = array("Document's price has been successfuly updated.","alert-success");
            header("Location:$prevLocation");
        } catch (\Throwable $th) {
            session_start();
            $_SESSION['processing-message-alert'] = array("There was a problem found! Please try again later.","alert-danger");
            header("Location:$prevLocation");
        }
    }
    else{
        header("Location:404.php");
    }

?>
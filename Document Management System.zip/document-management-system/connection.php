<?php

    $host = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'dms';

    $connect = mysqli_connect($host, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Connection Failed!";
	}
    
?>


<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">

                <a href="index.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="unpaid-doc-tab">
                    <i class="fa-solid fa-file-excel"></i>
                        Unpaid Documents
                    </div>
                </a>

                <a href="paid-documents-today.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="paid-doc-tab">
                    <i class="fa-solid fa-file-invoice-dollar"></i>
                        Paid Documents Today
                    </div>
                </a>

                <a href="reports.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="income-reports-tab">
                    <i class="fa-solid fa-folder-open"></i>
                        Reports
                    </div>
                </a>

                <a href="account-settings.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="account-settings-tab">
                        <i class="fa-solid fa-gear"></i>
                        Account Settings
                    </div>
                </a>

                

                <!-- <a class="nav-link templates-tab menu-tab" href="index.php">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-file-lines templates-tab menu-tab"></i></div>
                    Templates
                </a>

                <a class="nav-link documents-today-tab menu-tab" href="documents-today.php">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-file-lines documents-today-tab menu-tab"></i></div>
                    Documents Today
                </a>

                <a class="nav-link all-documents-tab menu-tab" href="all-documents.php">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-file-lines all-documents-tab menu-tab"></i></div>
                    All Documents
                </a> -->

            </div>
        </div>
    </nav>
</div>
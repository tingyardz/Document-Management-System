<?php
//A4 = 210 x 297 mm
// 1cm = 10mm
session_start();
require('fpdf.php');
require_once('../../connection.php');

class myPDF extends FPDF{

    function header(){
        // $this->Image('tutorial/logo.png',10,6);
        $this->SetFont('Arial','B',18);
        $this->Cell(190,5,$_SESSION['billing-title'],0,0,'C');
        $this->Ln(10);
        // $this->SetFont('Times','',12);
        // $this->Cell(276,10,'Andres-Dizon Bldg. Pioneer Ave. G.S.C.',0,0,'C');
        // $this->Ln(20);
    }
    function footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
    function headerTable(){
        $this->SetFont('Times','B',12);
        $this->Cell(30,10,'Date',0,0,'C');
        $this->Cell(30,10,'Doc No.',0,0,'C');
        $this->Cell(100,10,'Type of Document',0,0,'C');
        $this->Cell(30,10,'Amount',0,0,'C');
        $this->Ln();
    }
    function viewTable($connect){
        $this->SetFont('Times','',12);
        $selectedData = $_SESSION['create-bill'];
        $totalAmount= 0;

        foreach ($selectedData as $key => $value) {
            $sql = "SELECT * FROM `documents_tbl`
                    INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id`
                    JOIN `documents_title_tbl` ON `documents_title_tbl`.`Id` = `documents_tbl`.`Title_Id`
                    JOIN `price_tbl` ON `price_tbl`.`Temp_Id` = `documents_tbl`.`Temp_Id` WHERE `documents_tbl`.`Id` = '$value'";
            $query = $connect->query($sql) or die($connect->error);
            $row = $query->fetch_assoc();

            $this->Cell(30,10,$row['Date_Added'],0,0,'C');
            $this->Cell(30,10,$row['Doc_No'],0,0,'C');
            $this->Cell(100,10,$row['Title'],0,0,'C');
            $this->Cell(30,10,$this->formatPeso($row['Price']),0,0,'C');
            $this->Ln();

            $totalAmount = $totalAmount + $row['Price'];

        }

        $this->SetFont('Times','B',14);
        $this->Cell(30,10,'',0,0,'C');
        $this->Cell(30,10,'',0,0,'C');
        $this->Cell(100,10,'',0,0,'C');
        $this->Cell(30,10,$this->formatPeso($totalAmount),0,0,'C');
        $this->Ln(20);

        $this->SetFont('Times','',12);
        $this->Cell(95,10,'Prepared By:',0,0,'L');
        $this->Cell(95,10,'Noted By:',0,0,'L');
        $this->Ln();

        $this->SetFont('Times','B',12);
        $this->Cell(95,5,$_SESSION['dms-login-First_Name'].' '.$_SESSION['dms-login-Last_Name'],0,0,'C');
        $this->Cell(95,5,'Atty. Cyd Charisse Non-Dizon, REA, REB',0,0,'C');
        $this->Ln();

        $this->SetFont('Times','',10);
        $this->Cell(95,5,'Legal Department Staff',0,0,'C');
        $this->Cell(95,5,'School Administrator',0,0,'C');
        // $this->Cell(100,10,'',0,0,'C');
        // $this->Cell(30,10,'P800',0,0,'C');
        // $this->Ln();
        
        // if(isset($_SESSION['report-search-client-name'])){
        //     $clientName = $_SESSION['report-search-client-name'];
        //     $sql = "SELECT * FROM `documents_tbl` WHERE `Client_Name`='$clientName'";
        //     $query = $connect->query($sql) or die($connect->error);
        // }
        // else{
        //     $sql = "SELECT * FROM `documents_tbl`";
        //     $query = $connect->query($sql) or die($connect->error);
        // }

        // while($row = $query->fetch_assoc()){
        //     if(isset($_SESSION['date-From']) && isset($_SESSION['date-To'])){
        //         if($row['Date'] >= $_SESSION['date-From'] && $row['Date'] <= $_SESSION['date-To']){
        //             $this->Cell(30,10,$row['Date'],1,0,'C');
        //             $this->Cell(147,10,$row['Title'],1,0,'L');
        //             $this->Cell(50,10,$row['Client_Name'],1,0,'L');
        //             $this->Cell(50,10,$row['Secretary_Name'],1,0,'L');
        //             $this->Ln();
        //         }
        //     }
        //     else{
        //         if($row['Date'] == $_SESSION['date-today']){
        //             $this->Cell(30,10,$row['Date'],1,0,'C');
        //             $this->Cell(147,10,$row['Title'],1,0,'L');
        //             $this->Cell(50,10,$row['Client_Name'],1,0,'L');
        //             $this->Cell(50,10,$row['Secretary_Name'],1,0,'L');
        //             $this->Ln();
        //         }
        //     }
        // }
    }
    function formatPeso($currency){
        if($currency < 0){
          return "-".number_format(sprintf('%0.2f', preg_replace("/[^0-9.]/", "", $currency)),2);
        }else{
          return "".number_format(sprintf('%0.2f', preg_replace("/[^0-9.]/", "", $currency)),2);
        }
    }
      
}

if(isset($_SESSION['create-bill']) && isset($_SESSION['billing-title'])){
    $pdf = new myPDF();
    $pdf->AliasNbPages();
    $pdf->AddPage('P','A4',0);
    $pdf->headerTable();
    $pdf->viewTable($connect);
    $pdf->Output();

    unset($_SESSION['create-bill']);
    unset($_SESSION['billing-title']);
?>
<?php
}
else{
?>
    <script>window.close();</script>
<?php
}
?>
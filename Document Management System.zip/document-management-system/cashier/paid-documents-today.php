<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Cashier" && $_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }

    $dateToday = $_SESSION['date-today'];
    $sql = "SELECT * FROM `documents_tbl` 
            INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id`
            JOIN `documents_title_tbl` ON `documents_title_tbl`.`Id` = `documents_tbl`.`Title_Id` WHERE `documents_tbl`.`Status`='1' AND `Date_Added`='$dateToday' ORDER BY `documents_tbl`.`Id` DESC";
    $query = $connect->query($sql) or die($connect->error);
    $row = $query->fetch_assoc();
    $total = $query->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $_SESSION['dms-login-User_Type']; ?> | DMS</title>
        <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../bootstrap/css/simple-datatables@latest.css">
        <link rel="stylesheet" href="../bootstrap/css/table.style.css">
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/all.min.css">
        <link rel="stylesheet" href="css/paid-documents-today.css">
        <script src="js/jquery.min.js"></script>

   </head>
    <body class="sb-nav-fixed">

        <?php require_once("top-bar.php"); ?>

        <div id="layoutSidenav">
            <?php 
                switch ($_SESSION['dms-login-User_Type']) {
                    case 'Cashier':
                        require_once('navbar.php');
                        break;
                    case 'Admin':
                        require_once('navbar-admin.php');
                        break;
                    
                    default:
                        # code...
                        break;
                }
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Paid Documents Today</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home</li>
                            <li class="breadcrumb-item active">Paid Documents Today</li>
                        </ol>
                        <div class="row">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-table me-1"></i>
                                    Documents List
                                </div>
                                <div class="card-body">
                                    <table id="datatablesSimple" class="table-dark">
                                        <thead>
                                            <tr>
                                                <th>Doc No.</th>
                                                <th>Title</th>
                                                <th>Client Name</th>
                                                <th>Produced by</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if($total){
                                                    do{
                                            ?>
                                            <tr>
                                                <td><?php echo $row['Doc_No']; ?></td>
                                                <td><?php echo $row['Title']; ?></td>
                                                <td><?php echo $row['Client_Name']; ?></td>
                                                <td><?php echo $row['Produced_By']; ?></td>
                                                <td><?php echo $row['Date_Added']; ?></td>
                                                <td class="text-center"><div class="border bg-success text-light d-inline-block px-1 rounded">PAID</div></td>
                                            </tr>
                                            <?php
                                                    }while($row = $query->fetch_assoc());
                                                }
                                            ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>


        <!-- Javascript -->
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="../bootstrap/js/datatables-simple-demo.js"></script>
        <script src="../bootstrap/js/simple-datatables@latest.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/paid-documents-today.js"></script>
    </body>
</html>

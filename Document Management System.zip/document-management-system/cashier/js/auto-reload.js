checkingData();
var permissionToReload = null;

if(totalUnpaidDoc == 0){
    permissionToReload = true;
}

function checkingData(){
    setTimeout(() => {
        $(document).ready(function(){
            $.post(
                '../ajax-process.php',
                {
                    action : "getTotalUnpaidDoc"
                },
                function(data){

                    var checkbox = $('.checkbox');
                    for (let index = 0; index < checkbox.length; index++) {
                        if(checkbox[index].checked){
                            permissionToReload = false;
                            break;
                        }
                        else{
                            permissionToReload = true;
                        }
                    }

                    if(data > totalUnpaidDoc || data < totalUnpaidDoc){
                        if(permissionToReload == true){
                            reloadTable();
                            totalUnpaidDoc = data;

                            if(totalUnpaidDoc == 0){
                                $('#selected-item').attr('disabled',true);
                                $('#search-input').attr('disabled',true);
                                $('#select-all').attr('disabled',true);
                            }
                            else{
                                $('#selected-item').removeAttr('disabled');
                                $('#search-input').removeAttr('disabled');
                                $('#select-all').removeAttr('disabled');
                            }
                        }
                    }

                    checkingData();

                }
            );
        });
    }, 5000);
}

function reloadTable(){
    $(document).ready(function(){
        $('tbody').load(
            '../ajax-process.php',
            {
                action : "getNewUnpaidDoc"
            }
        );
    });
}
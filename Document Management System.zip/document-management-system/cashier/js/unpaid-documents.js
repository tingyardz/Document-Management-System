let documentOriginalAmount;

if(totalUnpaidDoc == 0){
    $('#selected-item').attr('disabled',true);
    $('#search-input').attr('disabled',true);
    $('#select-all').attr('disabled',true);
}

function setPayment(id,title,price,clientName){
    let discount = $('#discount-payment').val();
    const formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'PHP',
      });
    documentOriginalAmount = price;
    $('#documentId').val(id);
    $('#recipient-name-single').val(clientName);
    $('#document-title-payment').val(title);
    $('#display-document-title-payment').html(title);
    var finalAmount = documentOriginalAmount - (price * (discount / 100));
    $('#amount-payment').val(finalAmount);
    $('#display-amount-payment').html(formatter.format(finalAmount));


}

function checkbox(){
    var checkbox = document.querySelectorAll('.checkbox');
    var count = 0;
    for (let index = 0; index < checkbox.length; index++) {
        if(checkbox[index].checked){
            count++;
        }
    }
    $('#selected-count').html(count);
}

$(document).ready(function(){

    var selectedData = [];

    $('#select-all').on('click',function(){
        if(this.checked){
            var checkbox = $('.checkbox');
            for (let index = 0; index < checkbox.length; index++) {
                checkbox[index].checked = true;
            }
            $('#selected-count').html(checkbox.length);
        }
        else{
            var checkbox = $('.checkbox');
            for (let index = 0; index < checkbox.length; index++) {
                checkbox[index].checked = false;
            }
            $('#selected-count').html(0);
        }
    });

    $('#selected-item').on('change',function(){
        selectedData = [];
        var checkbox = $('.checkbox');
        for (let index = 0; index < checkbox.length; index++) {
            if(checkbox[index].checked){
                selectedData.push(checkbox[index].value);
            }
        }

        if(selectedData.length > 0){
            if(this.value == "Create Billing"){
                $('.create-billing-modal').removeClass('d-none');
                var docId = selectedData[0];
                $.post(
                    '../ajax-process.php',
                    {
                        action : "getDefaultName",
                        id : docId
                    },
                    function(data){
                        $('#billing-title').val(data);
                    }
                );
            }
            else if(this.value == "Pay Now"){
                $('.multiple-payment-modal').removeClass('d-none');
                var docId = selectedData[0];
                $.post(
                    '../ajax-process.php',
                    {
                        action : "getDefaultName",
                        id : docId
                    },
                    function(data){
                        console.log(data);
                        $('#recipient-name').val(data);
                    }
                );

                $.ajax({
                    type : 'POST',
                    url : '../ajax-process.php',
                    data : {
                        action : 'getDataForMultipleDocuments',
                        selectedData : selectedData
                    }
                }).then(function(response){
                    console.log(response);
                    documentOriginalAmount = response;
                    const formatter = new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'PHP',
                      });                  
                    $('#multiple-amount-payment').val(response);
                    $('#multiple-amount-payment').html(formatter.format(response));
                }).fail(function(response){
                    console.log(response.status);
                });

            }

        }
        else{
            alert('No data selected!');
            window.location.href="index.php";
        }

    });

    $('#create-billing-modal-close').on('click',function(){
        $('.create-billing-modal').addClass('d-none');
        selectedData = [];
    });

    $('#multiple-payment-modal-close').on('click',function(){
        $('.multiple-payment-modal').addClass('d-none');
        selectedData = [];
    });

    $('#create-bill').on('click',function(){
        var billingTitle = $('#billing-title').val();
        $.post(
            '../ajax-process.php',
            {
                action : 'createBill',
                selectedData : selectedData,
                billingTitle : billingTitle
            },
            function(data){
                if(data === "SUCCESS"){
                    window.openNewWindow('bill');
                    $('.create-billing-modal').addClass('d-none');
                }
                else{
                    alert("There was a problem with your server!");
                    window.location.href="index.php";
                }
            }
        );
    });

    $('#search-input').keyup(function(){
        var searchInput = this.value;
        $.ajax({
            type : 'POST',
            url : '../ajax-process.php',
            data : {
                action : 'searchUnpaidDoc',
                search : searchInput
            }
        }).then(function(response){
            $('tbody').html(response);
        }).fail(function(response){
            console.log(response.status);
        });

        document.getElementById('select-all').checked = false;
        document.getElementById('selected-count').innerHTML = 0;
    });

    $('#discount-payment').on('change',function(){
        var discount = documentOriginalAmount * (this.value / 100);
        var finalAmount = documentOriginalAmount - discount;
        const formatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'PHP',
          });      
        $('#amount-payment').val(documentOriginalAmount);
        $('#display-amount-payment').html(formatter.format(finalAmount));
    });

    $('#cash-payment').keyup(function(){
        var cash = this.value;
        var amount = $('#amount-payment').val();
        var discount = $('#discount-payment').val();
        var finalAmount = amount - (amount * (discount / 100));
        var change = cash - finalAmount;
        const formatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'PHP',
          });
      
        $('#change-payment').val(change);
        $('#display-change-payment').html(formatter.format(change));
    });

    $('#multiple-discount-payment').on('change',function(){
        var discount = documentOriginalAmount * (this.value / 100);
        var finalAmount = documentOriginalAmount - discount;
        const formatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'PHP',
          });      
        $('#multiple-amount-payment').val(documentOriginalAmount);
        $('#multiple-amount-payment').html(formatter.format(finalAmount));
    });

    $('#multiple-cash-payment').keyup(function(){
        var cash = this.value;
        var amount = $('#multiple-amount-payment').val();
        var discount = $('#multiple-discount-payment').val();
        var finalAmount = amount - (amount * (discount / 100));
        var change = cash - finalAmount;
        const formatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'PHP',
          });      
        $('#multiple-change-payment').val(change);
        $('#multiple-display-change-payment').html(formatter.format(change));
    });
    
    // higlights active module
    $('#billing-dropDown').removeClass('collapsed');
    $('#billing-dropDown').attr('aria-expanded', true);
    $('#collapseBilling').addClass('show');
});

//check alert message
$(document).ready(function(){
    $.post(
        '../ajax-process.php',
        {
            action: 'getProcessMessageAlert'
        },
        function(data){
            if(data){
                let value = JSON.parse(data);
                $('#processing-message-alert').removeClass('d-none');
                $('#processing-message-alert').addClass(value[1]);
                $('#processing-message-alert').html(value[0]);
                setTimeout(() => {
                    $('#processing-message-alert').addClass('d-none');
                }, 5000);
            }
        }
    );
});

//Open New Window
function openNewWindow(pageURL) {
    var preferedWidth = screen.width * 0.80;
    var preferedHeight = screen.height * 0.80;
    var left = (screen.width - preferedWidth) / 2;
    var top = (screen.height - preferedHeight) / 4;
    
    var myWindow = window.open(pageURL, '','resizable=yes, width=' + preferedWidth + ', height=' + preferedHeight + ', top=' + top + ', left=' + left);
}

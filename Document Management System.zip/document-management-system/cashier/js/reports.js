$(document).ready(function(){
    // higlights active module
    $('#reports-dropDown').removeClass('collapsed');
    $('#reports-dropDown').attr('aria-expanded', true);
    $('#collapseReports').addClass('show');
});
$(document).ready(function(){
    // higlights active module
    $('#billing-dropDown').removeClass('collapsed');
    $('#billing-dropDown').attr('aria-expanded', true);
    $('#collapseBilling').addClass('show');
});
<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Cashier" && $_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }

    date_default_timezone_set("Asia/Kuala_Lumpur");
    $dateToday = date("Y-m-d");


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['dms-login-User_Type']; ?> | DMS</title>
    <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap/css/simple-datatables@latest.css">
    <link rel="stylesheet" href="../bootstrap/css/table.style.css">
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/reports.css">
    <script src="js/jquery.min.js"></script>

</head>
<body class="sb-nav-fixed">

    <?php require_once("top-bar.php"); ?>

    <div id="layoutSidenav">

        <!-- Navigation Bar -->
        <?php 
            switch ($_SESSION['dms-login-User_Type']) {
                case 'Cashier':
                    require_once('navbar.php');
                    break;
                case 'Admin':
                    require_once('navbar-admin.php');
                    break;
                
                default:
                    # code...
                    break;
            }
        ?>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Reports</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Home</li>
                        <li class="breadcrumb-item active">Reports</li>
                    </ol>
                    <div class="row mb-5">
                        <div style="text-align: right;">
                            <form style="border-bottom:solid 2px black" class="bg-secondary p-2" action="../form-process.php" method="POST">
                                <label class="text-light">From: </label>
                                <input class="mx-2" type="date" name="date-from" value="<?php if(!isset($_SESSION['date-From']) && !isset($_SESSION['date-To'])){echo $dateToday;}else{echo $_SESSION['date-From'];} ?>" required>
                                <label class="text-light">To: </label>
                                <input class="mx-2" type="date" name="date-to" value="<?php if(!isset($_SESSION['date-From']) && !isset($_SESSION['date-To'])){echo $dateToday;}else{echo $_SESSION['date-To'];} ?>" required>
                                <button type="submit" name="search-cashier-report"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
                            </form>
                        </div>

                        <iframe src="print-reports" style="height:600px;" frameborder="0"></iframe>

                    </div>
                </div>
            </main>
        </div>
    </div>
    



    <!-- Javascript -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/datatables-simple-demo.js"></script>
    <script src="../bootstrap/js/simple-datatables@latest.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/reports.js"></script>

</body>
</html>
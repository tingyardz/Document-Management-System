<?php

//A4 = 210 x 297 mm
// 1cm = 10mm
session_start();
require('fpdf.php');
require_once('../../connection.php');

class myPDF extends FPDF{

    function header(){
        // $this->Image('tutorial/logo.png',10,6);
        $this->SetFont('Arial','B',14);
        $this->Cell(276,5,'Non-Dizon Law and Reality Office',0,0,'C');
        $this->Ln();
        $this->SetFont('Times','',12);
        $this->Cell(276,10,'Andres-Dizon Bldg. Pioneer Ave. G.S.C.',0,0,'C');
        $this->Ln(20);
    }
    function footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
    function headerTable(){
        $this->SetFont('Times','B',12);
        $this->Cell(57,10,'Recipient',1,0,'C');
        $this->Cell(30,10,'Date',1,0,'C');
        $this->Cell(100,10,'Type of Document',1,0,'C');
        $this->Cell(30,10,'Amount',1,0,'C');
        $this->Cell(30,10,'Discount',1,0,'C');
        $this->Cell(30,10,'Total',1,0,'C');
        $this->Ln();
    }
    function viewTable($connect){
        $this->SetFont('Times','',12);

        date_default_timezone_set("Asia/Kuala_Lumpur");
        $dateToday = date("Y-m-d");

        $sql = "SELECT * FROM `payment_tbl`";
        $query = $connect->query($sql) or die($connect->error);
        $row = $query->fetch_assoc();
        $total = $query->num_rows;
        $totalAmount = 0;
        $results = false;

        if($total){
            do{
                if(isset($_SESSION['date-From']) && isset($_SESSION['date-To'])){
                    $date = $row['Date'];
                    $dateFrom = $_SESSION['date-From'];
                    $dateTo = $_SESSION['date-To'];
                    if($date >= $dateFrom && $date <= $dateTo){
                        $this->Cell(57,10,$row['Recipient_Name'],1,0,'C');
                        $this->Cell(30,10,$row['Date'],1,0,'C');
                        $this->Cell(100,10,$row['Document_Title'],1,0,'C');
                        $this->Cell(30,10,$this->formatPeso($row['Original_Amount']),1,0,'C');
                        $this->Cell(30,10,$row['Discount'],1,0,'C');
                        $this->Cell(30,10,$this->formatPeso($row['Final_Amount']),1,0,'C');
                        $this->Ln();
                        $totalAmount = $totalAmount + $row['Final_Amount'];
                        $results = true;
                    }
                }
                else{
                    if($row['Date'] == $dateToday){
                        $this->Cell(57,10,$row['Recipient_Name'],1,0,'C');
                        $this->Cell(30,10,$row['Date'],1,0,'C');
                        $this->Cell(100,10,$row['Document_Title'],1,0,'C');
                        $this->Cell(30,10,$this->formatPeso($row['Original_Amount']),1,0,'C');
                        $this->Cell(30,10,$row['Discount'],1,0,'C');
                        $this->Cell(30,10,$this->formatPeso($row['Final_Amount']),1,0,'C');
                        $this->Ln();
                        $totalAmount = $totalAmount + $row['Final_Amount'];
                        $results = true;
                    }
                }

            }while($row = $query->fetch_assoc());

            if($results){
                $this->SetFont('Times','B',12);

                $this->Cell(57,10,'',0,0,'C');
                $this->Cell(30,10,'',0,0,'C');
                $this->Cell(100,10,'',0,0,'C');
                $this->Cell(30,10,'',0,0,'C');
                $this->Cell(30,10,'',0,0,'C');
                $this->Cell(30,10,$this->formatPeso($totalAmount),0,0,'C');
            }
            else{
                $this->SetFont('Times','B',16);

                $this->Cell(277,40,'No Available Data',0,0,'C');
            }

        }

    }
    function formatPeso($currency){
        if($currency < 0){
          return "-".number_format(sprintf('%0.2f', preg_replace("/[^0-9.]/", "", $currency)),2);
        }else{
          return "".number_format(sprintf('%0.2f', preg_replace("/[^0-9.]/", "", $currency)),2);
        }
    }    

}

$pdf = new myPDF();
$pdf->AliasNbPages();
$pdf->AddPage('L','A4',0);
$pdf->headerTable();
$pdf->viewTable($connect);
$pdf->Output();

?>
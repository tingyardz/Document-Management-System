<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Cashier" && $_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }

    $sql = "SELECT *, `documents_tbl`.`Status` AS `doc_status`, `documents_tbl`.`Id` AS `doc_id` FROM `documents_tbl`
            INNER JOIN `documents_title_tbl` ON `documents_title_tbl`.`Id` = `documents_tbl`.`Title_Id`
            JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id`
            JOIN `price_tbl` ON `price_tbl`.`Temp_Id` = `documents_tbl`.`Temp_Id`
            WHERE `documents_tbl`.`Status`='0' ORDER BY `documents_tbl`.`Id` DESC";
    $query = $connect->query($sql) or die($connect->error);
    $row = $query->fetch_assoc();
    $total = $query->num_rows;
    $completeDocs = 0;
    $numOfRows = 0;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $_SESSION['dms-login-User_Type']; ?> | DMS</title>
        <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/all.min.css">
        <link rel="stylesheet" href="css/index.css">
        <script src="js/jquery.min.js"></script>

   </head>
    <body class="sb-nav-fixed">

        <?php require_once("top-bar.php"); ?>

        <div id="layoutSidenav">
            <?php 
                switch ($_SESSION['dms-login-User_Type']) {
                    case 'Cashier':
                        require_once('navbar.php');
                        break;
                    case 'Admin':
                        require_once('navbar-admin.php');
                        break;
                    
                    default:
                        # code...
                        break;
                }
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Unpaid Documents</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home</li>
                            <li class="breadcrumb-item active">Unpaid Documents</li>
                        </ol>

                        <!-- Alert -->
                        <div id="processing-message-alert" class="alert d-none text-center" role="alert"></div>

                        <div class="row">

                            <div class="card mb-4 pb-3">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Document List
                            </div>
                            <div>
                                <div class="ms-3 mt-3" style="display:inline-block;">
                                    <div class="py-2" style="height:40px;">
                                        <input id="select-all" class="form-check-input"  type="checkbox">
                                        <label for=""> Select All</label>
                                    </div>
                                </div>

                                <div class="ms-3 mt-3" style="display:inline-block;">
                                    <div class="py-2" style="height:40px;">
                                        <label>Selected: </label>
                                        <p id="selected-count" style="display:inline-block;">0</p>
                                    </div>
                                </div>

                                <div class="ms-3 mt-3" style="display:inline-block;">
                                    <select class="form-select" name="" id="selected-item">
                                        <option value="">With the selected item:</option>
                                        <option value="Create Billing">Create Bill</option>
                                        <option value="Pay Now">Pay Now</option>
                                    </select>
                                </div>

                                <div class="ms-3 mt-3" style="display:inline-block;">
                                    <input id="search-input" class="form-control" type="text" placeholder="Search client name...">
                                </div>

                            </div>
                            <div class="card-body py-0 mt-3" style="height:310px;overflow-y:auto;">
                                <table id="datatablesSimple" class="table mb-0 table-dark">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Doc No.</th>
                                            <th>Title</th>
                                            <th>Client Name</th>
                                            <th>Produced By</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if($total){
                                            do{
                                                $docNo = $row['Doc_No'];
                                                $pageNo = $row['Page_No'];
                                                $bookNo = $row['Book_No'];
                                                $seriesOf = $row['Series_of'];
                                                if(!empty($docNo) && !empty($pageNo) && !empty($bookNo) && !empty($seriesOf)){
                                                    $numOfRows++;
                                        ?>
                                        <tr>
                                            <td><input onclick="checkbox()" class="checkbox" type="checkbox" value="<?php echo $row['doc_id']; ?>"></td>
                                            <td><?php echo $row['Doc_No']; ?></td>
                                            <td><?php echo $row['Title']; ?></td>
                                            <td><?php echo $row['Client_Name']; ?></td>
                                            <td><?php echo $row['Produced_By']; ?></td>
                                            <td><?php echo $row['Date_Added']; ?></td>
                                            <?php
                                                switch ($row['doc_status']) {
                                                    case '0':
                                                        $status = "UNPAID";
                                                        break;
                                                    case '1':
                                                        $status = "PAID";
                                                        break;
                                                }
                                            ?>
                                            <td class="text-danger"><?php echo $status; ?></td>
                                            <td><button onclick="setPayment(<?php echo $row['doc_id']; ?>,'<?php echo $row['Title']; ?>',<?php echo $row['Price']; ?>,'<?php echo $row['Client_Name']; ?>')" class="bg-success text-light p-1" style="border:none;" data-bs-toggle="modal" data-bs-target="#single-payment-modal">PayNow</button></td>
                                        </tr>
                                        <?php
                                                    $completeDocs++;
                                                }
                                            }while($row = $query->fetch_assoc());
                                        }
                                        ?>

                                        <?php
                                        if($total == 0 || $numOfRows == 0){
                                        ?>
                                        <tr><td class='dataTables-empty' colspan='8'>No entries found</td></tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            </div>
                            
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- Create Bill Modal -->
        <div class="create-billing-modal d-none">
            <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Billing</h5>
                    <button id="create-billing-modal-close" type="button" class="btn-close"></button>
                  </div>
                  <div class="modal-body">
                    <input id="billing-title" type="text" class="form-control" placeholder="Billing Title">
                  </div>
                  <div class="modal-footer mb-2">
                    <button id="create-bill" type="button" class="btn btn-primary w-75" style="margin:auto;">Create Bill</button>
                  </div>
                </div>
            </div>
        </div>

        <!-- Multiple Payment Modal -->
        <div class="multiple-payment-modal d-none">
            <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Payment Transaction</h5>
                    <button id="multiple-payment-modal-close" type="button" class="btn-close"></button>
                  </div>
                  <div class="modal-body">
                        <form action="../form-process.php" method="POST">
                            <div class="form-floating mb-3">
                                <input class="form-control" id="recipient-name" type="text" name="recipient-name" placeholder="Recipient Name" required/>
                                <label for="recipient-name">Recipient Name</label>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <div class="form-control" id="multiple-amount-payment"></div>
                                        <label for="multiple-amount-payment">Total Amount</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-select" name="discount" id="multiple-discount-payment">
                                            <option value="0">0%</option>
                                            <option value="5">5%</option>
                                            <option value="10">10%</option>
                                        </select>
                                        <label for="multiple-discount-payment">Discount</label>
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <input class="form-control" id="multiple-cash-payment" type="number" step="0.01" placeholder="Cash" />
                                        <label for="multiple-cash-payment">Cash</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input class="form-control d-none" id="multiple-change-payment" type="number" step="0.01" placeholder="Change" />
                                        <div class="form-control" id="multiple-display-change-payment"></div>
                                        <label for="multiple-display-change-payment">Change</label>
                                    </div>
                                </div>
                            </div>
                    
                  </div>
                  <div class="modal-footer mb-2">
                    <button type="submit" name="submit-payment-multiple" class="btn btn-primary w-50" style="margin:auto;">Submit Payment</button>
                  </div>
                        </form>
                </div>
            </div>
        </div>

        <!-- Single Payment Modal -->
        <div class="modal fade" id="single-payment-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Payment Transaction</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="../form-process.php" method="POST">
                    <div class="form-floating mb-3 d-none">
                        <input class="form-control" id="documentId" type="number" name="documentId" placeholder="Document Id"/>
                        <label for="documentId">Document Id</label>
                    </div>

                    <div class="form-floating mb-3">
                        <input class="form-control" id="recipient-name-single" type="text" name="recipient-name" placeholder="Recipient Name" required/>
                        <label for="recipient-name">Recipient Name</label>
                    </div>

                    <div class="form-floating mb-3">
                        <input class="form-control d-none" id="document-title-payment" type="text" name="document-title" placeholder="Document Title" />
                        <div class="form-control" id="display-document-title-payment"></div>
                        <label for="display-document-title-payment">Type of Document</label>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-floating mb-3 mb-md-0">
                                <input class="form-control d-none" id="amount-payment" type="number" step="0.01" name="amount" placeholder="Amount" />
                                <div class="form-control" id="display-amount-payment"></div>
                                <label for="display-amount-payment">Amount</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" name="discount" id="discount-payment">
                                    <option id="discount-payment-default" value="0">0%</option>
                                    <option value="5">5%</option>
                                    <option value="10">10%</option>
                                </select>
                                <label for="discount-payment">Discount</label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-floating mb-3 mb-md-0">
                                <input class="form-control" id="cash-payment" type="number" step="0.01" placeholder="Cash" />
                                <label for="cash-payment">Cash</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input class="form-control d-none" id="change-payment" type="number" step="0.01" placeholder="Change" />
                                <div class="form-control" id="display-change-payment"></div>
                                <label for="display-change-payment">Change</label>
                            </div>
                        </div>
                    </div>

              </div>
              <div class="modal-footer mb-2">
                <button style="margin:auto;" type="submit" name="submit-single-payment" class="btn btn-primary w-75">Submit Payment</button>
              </div>
                </form>
            </div>
          </div>
        </div>


        <!-- Javascript -->
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script>var totalUnpaidDoc = <?php echo $completeDocs; ?>;</script>
        <script src="js/unpaid-documents.js"></script>
    </body>
</html>

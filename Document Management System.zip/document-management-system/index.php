<?php
    session_start();
    if(isset($_SESSION['dms-login-User_Type'])){
        $user = $_SESSION['dms-login-User_Type'];
        switch ($user) {
            case 'Secretary':
                header('Location:secretary');
                break;
            case 'Cashier':
                header('Location:cashier');
                break;
            case 'Admin':
                header('Location:admin');
                break;
        }
    }

    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Document Management System | Non-Dizon Law Office</title>
        <link rel="shortcut icon" href="img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/index.css">  
    </head>
    <body class="bg-secondary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Login</h3></div>
                                    <div class="card-body">
                                        <form action="form-process.php" method="POST">
                                            <div id="login-alert" style="display:none;" class="bg-danger text-light text-center p-3 mb-3"><h6 class="m-0">You have entered incorrect inputs!</h6></div>
                                            <div class="form-floating mb-3" style="display:none;">
                                                <input class="form-control" name="date-today" id="date-today" type="text" placeholder="Date Today" />
                                                <label for="date-today">Date Today</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input required class="form-control" name="username" id="username" type="text" placeholder="Username" />
                                                <label for="username">Username</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input required class="form-control" name="password" id="inputPassword" type="password" placeholder="Password" />
                                                <label for="inputPassword">Password</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <button class="btn btn-primary w-75" name="login-user" type="submit" style="margin:auto;">Login</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <?php
            if(isset($_SESSION['dms-login'])){
                if($_SESSION['dms-login'] === false){
        ?>
        <script>document.querySelector('#login-alert').style = "display:block;"</script>
        <?php
                    $_SESSION['dms-login'] = true;
                }
            }
        ?>
        <script>
            let date = new Date();
            let currentYear = date.getFullYear();
            let currentMonth = date.getMonth() + 1;
            let currentDate = date.getDate();
            let dateToday = currentYear +'-'+ currentMonth +'-'+ currentDate;
            document.querySelector('#date-today').value = dateToday;
        </script>
    </body>
</html>

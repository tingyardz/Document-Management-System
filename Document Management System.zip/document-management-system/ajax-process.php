<?php
    require_once('connection.php');
    require_once('methods.php');
    $method = new Methods();
    if(!isset($_POST['action'])){
        header("Location:404.php");
    }
    $action = $_POST['action'];

    switch ($action) {
        case 'removeTemplate':
            echo $method->removeTemplate();
            break;
        case 'getDocumentData':
            echo $method->getDocumentData();
            break;
        case 'removeDocument':
            echo $method->removeDocument();
            break;
        case 'getTotalUnpaidDoc':
            echo $method->getTotalUnpaidDoc();
            break;
        case 'getNewUnpaidDoc':
            echo $method->getNewUnpaidDoc();
            break;
        case 'createBill':
            echo $method->createBill();
            break;
        case 'searchUnpaidDoc':
            echo $method->searchUnpaidDoc();
            break;
        case 'getDataForMultipleDocuments':
            echo $method->getDataForMultipleDocuments();
            break;
        case 'getUserData':
            echo $method->getUserData();
            break;
        case 'removeUser':
            echo $method->removeUser();
            break;
        case 'getDocumentPrice':
            echo $method->getDocumentPrice();
            break;
        case 'removeDataFromPriceTable':
            echo $method->removeDataFromPriceTable();
            break;
        case 'getTheNumberOfTheNewTemplate':
            echo $method->getTheNumberOfTheNewTemplate();
            break;
        case 'getNewTemplateData':
            echo $method->getNewTemplateData();
            break;
        case 'getDataFromTemplatesTable':
            echo $method->getDataFromTemplatesTable();
            break;
        case 'getNumberOfDataFromTemplatesTable':
            echo $method->getNumberOfDataFromTemplatesTable();
            break;
        case 'getDataFromDocumentsTableForToday':
            echo $method->getDataFromDocumentsTableForToday();
            break;
        case 'getNumberOfDataFromDocumentsTableForToday':
            echo $method->getNumberOfDataFromDocumentsTableForToday();
            break;
        case 'getAllDataFromDocumentsTable':
            echo $method->getAllDataFromDocumentsTable();
            break;
        case 'getNumberOfDataFromDocumentsTable':
            echo $method->getNumberOfDataFromDocumentsTable();
            break;
        case 'getTheNumberOfDisabledTemplates':
            echo $method->getTheNumberOfDisabledTemplates();
            break;
        case 'getSubDocData':
            echo $method->getSubDocData();
            break;
        case 'getProcessMessageAlert':
            echo $method->getProcessMessageAlert();
            break;
        case 'getAllStats':
            echo $method->getAllStats();
            break;
        case 'getAllPassingYears':
            echo $method->getAllPassingYears();
            break;
        case 'getTotalDocumentsThisYear':
            echo $method->getTotalDocumentsThisYear();
            break;
        case 'getTotalIncomePerMonth':
            echo $method->getTotalIncomePerMonth();
            break;
        case 'getOverallIncome':
            echo $method->getOverallIncome();
            break;
        case 'getTheTop5MostRequestedDocuments':
            echo $method->getTheTop5MostRequestedDocuments();
            break;
        case 'getTheNumberOfPaidDocuments':
            echo $method->getTheNumberOfPaidDocuments();
            break;
        case 'searchForDocTitle':
            echo $method->searchForDocTitle();
            break;
        case 'getTemplatesFrom':
            echo $method->getTemplatesFrom();
            break;
        case 'getTemplatesData':
            echo $method->getTemplatesData();
            break;
        case 'getClientData':
            echo $method->getClientData();
            break;
        case 'removeClientData':
            echo $method->removeClientData();
            break;
        case 'getClientDocket':
            echo $method->getClientDocket();
            break;
        case 'getTemplatesData01':
            echo $method->getTemplatesData01();
            break;
        case 'getDefaultName':
            echo $method->getDefaultName();
            break;
        case 'getOverallDocuments':
            echo $method->getOverallDocuments();
            break;
        case 'getTotalDocumentsToday':
            echo $method->getTotalDocumentsToday();
            break;
        case 'getTemplateStatus':
            echo $method->getTemplateStatus();
            break;
        case 'searchClientName':
            echo $method->searchClientName();
            break;
        case 'searchingForReports':
            echo $method->searchingForReports();
            break;
    }
    
?>
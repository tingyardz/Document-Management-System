-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2023 at 07:13 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dms`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_data_structure_tbl`
--

CREATE TABLE `client_data_structure_tbl` (
  `Id` int(11) NOT NULL,
  `Title_Id` int(11) NOT NULL,
  `Client_Form` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client_data_structure_tbl`
--

INSERT INTO `client_data_structure_tbl` (`Id`, `Title_Id`, `Client_Form`) VALUES
(1, 1, '                    <div class=\"row mb-3\">\n                        <div class=\"col-4\">\n                            <div class=\"form-floating mb-3 mb-md-0\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-first-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your first name\" required/>\n                                <label for=\"input-affiant-first-name\">Affiant First Name</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-middle-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your middle name\" required/>\n                                <label for=\"input-affiant-middle-name\">Affiant Middle Name</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-last-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your last name\" required/>\n                                <label for=\"input-affiant-last-name\">Affiant Last Name</label>\n                            </div>\n                        </div>\n                    </div>\n\n                    <div class=\"row mb-3\">\n                        <div class=\"col-4\">\n                            <div class=\"form-floating mb-3 mb-md-0\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-age\" type=\"number\" name=\"basic-input[]\" placeholder=\"Enter your age\" required/>\n                                <label for=\"input-affiant-age\">Affiant Age</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-citizenship\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your citizenship\" required/>\n                                <label for=\"input-affiant-citizenship\">Affiant Citizenship</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-legal-status\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your legal status\" required/>\n                                <label for=\"input-affiant-legal-status\">Affiant Legal Status</label>\n                            </div>\n                        </div>\n                    </div>\n\n                    <div class=\"row mb-3\">\n                        <div class=\"col-4\">\n                            <div class=\"form-floating mb-3 mb-md-0\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-address\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your address\" required/>\n                                <label for=\"input-affiant-address\">Affiant Address</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-valid-id\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your valid id\" required/>\n                                <label for=\"input-affiant-valid-id\">Valid Id</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control basic-input\" id=\"input-affiant-idExpDate\" type=\"text\" name=\"basic-input[]\" placeholder=\"Id Expiration Date\" />\n                                <label for=\"input-affiant-idExpDate\">Id Exp. Date</label>\n                            </div>\n                        </div>\n                    </div>\n\n\n                    <div style=\"width:666px;\">\n                        <div class=\"mb-3\">\n                            <label class=\"mb-2\"><strong>Statements</strong></label>\n                            <textarea name=\"clientData[]\" id=\"statements\"></textarea>\n                        </div>\n                    </div>\n\n\n                    <div class=\"row mb-3\">\n                        <div class=\"col-4\">\n                            <div class=\"form-floating mb-3 mb-md-0\">\n                                <input class=\"form-control docket-input\" id=\"input-doc-number\" type=\"text\" name=\"doc-no\" placeholder=\"Document Number\"/>\n                                <label for=\"input-doc-number\">Doc No</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control docket-input\" id=\"input-page-number\" type=\"text\" name=\"page-no\" placeholder=\"Page Number\"/>\n                                <label for=\"input-page-number\">Page No</label>\n                            </div>\n                        </div>\n                    </div>\n\n                    <div class=\"row mb-3\">\n                        <div class=\"col-4\">\n                            <div class=\"form-floating mb-3 mb-md-0\">\n                                <input class=\"form-control docket-input\" id=\"input-book-number\" type=\"text\" name=\"book-no\" placeholder=\"Book Number\"/>\n                                <label for=\"input-book-number\">Book No</label>\n                            </div>\n                        </div>\n                        <div class=\"col-4\">\n                            <div class=\"form-floating\">\n                                <input class=\"form-control docket-input\" id=\"input-series-of\" type=\"text\" name=\"series-of\" placeholder=\"Series of\"/>\n                                <label for=\"input-series-of\">Series of</label>\n                            </div>\n                        </div>\n                    </div>\n					\n					\n'),
(2, 3, '                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-first-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your first name\" required/>\r\n                                <label for=\"input-affiant-first-name\">Affiant First Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-middle-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your middle name\" required/>\r\n                                <label for=\"input-affiant-middle-name\">Affiant Middle Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-last-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your last name\" required/>\r\n                                <label for=\"input-affiant-last-name\">Affiant Last Name</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-age\" type=\"number\" name=\"basic-input[]\" placeholder=\"Enter your age\" required/>\r\n                                <label for=\"input-affiant-age\">Affiant Age</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-citizenship\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your citizenship\" required/>\r\n                                <label for=\"input-affiant-citizenship\">Affiant Citizenship</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-legal-status\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your legal status\" required/>\r\n                                <label for=\"input-affiant-legal-status\">Affiant Legal Status</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-address\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your address\" required/>\r\n                                <label for=\"input-affiant-address\">Affiant Address</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-valid-id\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your valid id\" required/>\r\n                                <label for=\"input-affiant-valid-id\">Valid Id</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-idExpDate\" type=\"text\" name=\"basic-input[]\" placeholder=\"Id Expiration Date\" />\r\n                                <label for=\"input-affiant-idExpDate\">Id Exp. Date</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div style=\"width:666px;\">\r\n                        <div class=\"mb-3\">\r\n                            <label class=\"mb-2\"><strong>Statements</strong></label>\r\n                            <textarea name=\"clientData[]\" id=\"statements\"></textarea>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-doc-number\" type=\"text\" name=\"doc-no\" placeholder=\"Document Number\"/>\r\n                                <label for=\"input-doc-number\">Doc No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-page-number\" type=\"text\" name=\"page-no\" placeholder=\"Page Number\"/>\r\n                                <label for=\"input-page-number\">Page No</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-book-number\" type=\"text\" name=\"book-no\" placeholder=\"Book Number\"/>\r\n                                <label for=\"input-book-number\">Book No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-series-of\" type=\"text\" name=\"series-of\" placeholder=\"Series of\"/>\r\n                                <label for=\"input-series-of\">Series of</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n'),
(3, 4, '                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-first-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your first name\" required/>\r\n                                <label for=\"input-affiant-first-name\">Affiant First Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-middle-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your middle name\" required/>\r\n                                <label for=\"input-affiant-middle-name\">Affiant Middle Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-last-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your last name\" required/>\r\n                                <label for=\"input-affiant-last-name\">Affiant Last Name</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-age\" type=\"number\" name=\"basic-input[]\" placeholder=\"Enter your age\" required/>\r\n                                <label for=\"input-affiant-age\">Affiant Age</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-citizenship\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your citizenship\" required/>\r\n                                <label for=\"input-affiant-citizenship\">Affiant Citizenship</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-legal-status\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your legal status\" required/>\r\n                                <label for=\"input-affiant-legal-status\">Affiant Legal Status</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-address\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your address\" required/>\r\n                                <label for=\"input-affiant-address\">Affiant Address</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-valid-id\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your valid id\" required/>\r\n                                <label for=\"input-affiant-valid-id\">Valid Id</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-idExpDate\" type=\"text\" name=\"basic-input[]\" placeholder=\"Id Expiration Date\" />\r\n                                <label for=\"input-affiant-idExpDate\">Id Exp. Date</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div style=\"width:666px;\">\r\n                        <div class=\"mb-3\">\r\n                            <label class=\"mb-2\"><strong>Statements</strong></label>\r\n                            <textarea name=\"clientData[]\" id=\"statements\"></textarea>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-doc-number\" type=\"text\" name=\"doc-no\" placeholder=\"Document Number\"/>\r\n                                <label for=\"input-doc-number\">Doc No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-page-number\" type=\"text\" name=\"page-no\" placeholder=\"Page Number\"/>\r\n                                <label for=\"input-page-number\">Page No</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-book-number\" type=\"text\" name=\"book-no\" placeholder=\"Book Number\"/>\r\n                                <label for=\"input-book-number\">Book No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-series-of\" type=\"text\" name=\"series-of\" placeholder=\"Series of\"/>\r\n                                <label for=\"input-series-of\">Series of</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n'),
(4, 7, '                    \r\n					\r\n					\r\n					\r\n					<div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-first-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your first name\" required/>\r\n                                <label for=\"input-affiant-first-name\">Lessor First Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-middle-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your middle name\" required/>\r\n                                <label for=\"input-affiant-middle-name\">Lessor Middle Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-last-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your last name\" required/>\r\n                                <label for=\"input-affiant-last-name\">Lessor Last Name</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-age\" type=\"number\" name=\"basic-input[]\" placeholder=\"Enter your age\" required/>\r\n                                <label for=\"input-affiant-age\">Lessor Age</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-citizenship\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your citizenship\" required/>\r\n                                <label for=\"input-affiant-citizenship\">Lessor Citizenship</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-legal-status\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your legal status\" required/>\r\n                                <label for=\"input-affiant-legal-status\">Lessor Legal Status</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-address\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your address\" required/>\r\n                                <label for=\"input-affiant-address\">Lessor Address</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-valid-id\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your valid id\" required/>\r\n                                <label for=\"input-affiant-valid-id\">Valid Id</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-idExpDate\" type=\"text\" name=\"basic-input[]\" placeholder=\"Id Expiration Date\" />\r\n                                <label for=\"input-affiant-idExpDate\">Id Exp. Date</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n					\r\n					\r\n					<div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-first-name\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your first name\" required/>\r\n                                <label for=\"input-affiant-first-name\">Lessee First Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-middle-name\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your middle name\" required/>\r\n                                <label for=\"input-affiant-middle-name\">Lessee Middle Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-last-name\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your last name\" required/>\r\n                                <label for=\"input-affiant-last-name\">Lessee Last Name</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-age\" type=\"number\" name=\"clientData[]\" placeholder=\"Enter your age\" required/>\r\n                                <label for=\"input-affiant-age\">Lessee Age</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-citizenship\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your citizenship\" required/>\r\n                                <label for=\"input-affiant-citizenship\">Lessee Citizenship</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-legal-status\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your legal status\" required/>\r\n                                <label for=\"input-affiant-legal-status\">Lessee Legal Status</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-address\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your address\" required/>\r\n                                <label for=\"input-affiant-address\">Lessee Address</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-valid-id\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your valid id\" required/>\r\n                                <label for=\"input-affiant-valid-id\">Valid Id</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-idExpDate\" type=\"text\" name=\"clientData[]\" placeholder=\"Id Expiration Date\" />\r\n                                <label for=\"input-affiant-idExpDate\">Id Exp. Date</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n					<div class=\"row mb-3\">\r\n                        <div class=\"col-6\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-lessor-property-owned\" type=\"text\" name=\"clientData[]\" placeholder=\"Property Owned\" required/>\r\n                                <label for=\"input-lessor-property-owned\">The LESSOR is the owner of:</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-6\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-property-to-lease\" type=\"text\" name=\"clientData[]\" placeholder=\"Property to Lease\" required/>\r\n                                <label for=\"input-property-to-lease\">The LESSEE intends to lease the aforesaid:</label>\r\n                            </div>\r\n                        </div>\r\n						<div class=\"col-6 mt-3\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-lease-period\" type=\"text\" name=\"clientData[]\" placeholder=\"Lease Period\" required/>\r\n                                <label for=\"input-lease-period\">Lease Period</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					<div class=\"row mb-3\">\r\n                        <div class=\"col-6\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-witness-01\" type=\"text\" name=\"clientData[]\" placeholder=\"Witness Name\" required/>\r\n                                <label for=\"input-witness-01\">First Witness</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-6\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-witness-02\" type=\"text\" name=\"clientData[]\" placeholder=\"Witness Name\" required/>\r\n                                <label for=\"input-witness-02\">Second Witness</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n\r\n                    <div style=\"width:666px;\">\r\n                        <div class=\"mb-3\">\r\n                            <label class=\"mb-2\"><strong>Terms & Conditions</strong></label>\r\n                            <textarea name=\"clientData[]\" id=\"terms-and-conditions\"></textarea>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-doc-number\" type=\"text\" name=\"doc-no\" placeholder=\"Document Number\"/>\r\n                                <label for=\"input-doc-number\">Doc No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-page-number\" type=\"text\" name=\"page-no\" placeholder=\"Page Number\"/>\r\n                                <label for=\"input-page-number\">Page No</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-book-number\" type=\"text\" name=\"book-no\" placeholder=\"Book Number\"/>\r\n                                <label for=\"input-book-number\">Book No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-series-of\" type=\"text\" name=\"series-of\" placeholder=\"Series of\"/>\r\n                                <label for=\"input-series-of\">Series of</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n'),
(5, 8, '                    \r\n					\r\n					\r\n					\r\n					<div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-first-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your first name\" required/>\r\n                                <label for=\"input-affiant-first-name\">Principal First Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-middle-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your middle name\" required/>\r\n                                <label for=\"input-affiant-middle-name\">Principal Middle Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-last-name\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your last name\" required/>\r\n                                <label for=\"input-affiant-last-name\">Principal Last Name</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-age\" type=\"number\" name=\"basic-input[]\" placeholder=\"Enter your age\" required/>\r\n                                <label for=\"input-affiant-age\">Principal Age</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-citizenship\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your citizenship\" required/>\r\n                                <label for=\"input-affiant-citizenship\">Principal Citizenship</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-legal-status\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your legal status\" required/>\r\n                                <label for=\"input-affiant-legal-status\">Principal Legal Status</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-address\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your address\" required/>\r\n                                <label for=\"input-affiant-address\">Principal Address</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-valid-id\" type=\"text\" name=\"basic-input[]\" placeholder=\"Enter your valid id\" required/>\r\n                                <label for=\"input-affiant-valid-id\">Valid Id</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input\" id=\"input-affiant-idExpDate\" type=\"text\" name=\"basic-input[]\" placeholder=\"Id Expiration Date\" />\r\n                                <label for=\"input-affiant-idExpDate\">Id Exp. Date</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n					\r\n					\r\n					<div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-first-name\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your first name\" required/>\r\n                                <label for=\"input-affiant-first-name\">Appointee First Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-middle-name\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your middle name\" required/>\r\n                                <label for=\"input-affiant-middle-name\">Appointee Middle Name</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-last-name\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your last name\" required/>\r\n                                <label for=\"input-affiant-last-name\">Appointee Last Name</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-age\" type=\"number\" name=\"clientData[]\" placeholder=\"Enter your age\" required/>\r\n                                <label for=\"input-affiant-age\">Appointee Age</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-citizenship\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your citizenship\" required/>\r\n                                <label for=\"input-affiant-citizenship\">Appointee Citizenship</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-legal-status\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your legal status\" required/>\r\n                                <label for=\"input-affiant-legal-status\">Appointee Legal Status</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-address\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your address\" required/>\r\n                                <label for=\"input-affiant-address\">Appointee Address</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-valid-id\" type=\"text\" name=\"clientData[]\" placeholder=\"Enter your valid id\" required/>\r\n                                <label for=\"input-affiant-valid-id\">Valid Id</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-affiant-idExpDate\" type=\"text\" name=\"clientData[]\" placeholder=\"Id Expiration Date\" />\r\n                                <label for=\"input-affiant-idExpDate\">Id Exp. Date</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n					<div class=\"row mb-3\">\r\n                        <div class=\"col-6\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-witness-01\" type=\"text\" name=\"clientData[]\" placeholder=\"Witness Name\" required/>\r\n                                <label for=\"input-witness-01\">First Witness</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-6\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control basic-input-02\" id=\"input-witness-02\" type=\"text\" name=\"clientData[]\" placeholder=\"Witness Name\" required/>\r\n                                <label for=\"input-witness-02\">Second Witness</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n\r\n                    <div style=\"width:666px;\">\r\n                        <div class=\"mb-3\">\r\n                            <label class=\"mb-2\"><strong>Acts & Powers</strong></label>\r\n                            <textarea name=\"clientData[]\" id=\"acts-and-powers\"></textarea>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-doc-number\" type=\"text\" name=\"doc-no\" placeholder=\"Document Number\"/>\r\n                                <label for=\"input-doc-number\">Doc No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-page-number\" type=\"text\" name=\"page-no\" placeholder=\"Page Number\"/>\r\n                                <label for=\"input-page-number\">Page No</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row mb-3\">\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating mb-3 mb-md-0\">\r\n                                <input class=\"form-control docket-input\" id=\"input-book-number\" type=\"text\" name=\"book-no\" placeholder=\"Book Number\"/>\r\n                                <label for=\"input-book-number\">Book No</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-4\">\r\n                            <div class=\"form-floating\">\r\n                                <input class=\"form-control docket-input\" id=\"input-series-of\" type=\"text\" name=\"series-of\" placeholder=\"Series of\"/>\r\n                                <label for=\"input-series-of\">Series of</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n					\r\n					\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `client_data_tbl`
--

CREATE TABLE `client_data_tbl` (
  `Id` int(11) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Middle_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Age` int(11) NOT NULL,
  `Citizenship` varchar(50) NOT NULL,
  `Legal_Status` varchar(50) NOT NULL,
  `Address` text NOT NULL,
  `Valid_Id` varchar(50) NOT NULL,
  `Id_Exp` varchar(50) NOT NULL,
  `Client_Data` text NOT NULL,
  `Date_Added` date NOT NULL,
  `Time_Added` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client_data_tbl`
--

INSERT INTO `client_data_tbl` (`Id`, `First_Name`, `Middle_Name`, `Last_Name`, `Age`, `Citizenship`, `Legal_Status`, `Address`, `Valid_Id`, `Id_Exp`, `Client_Data`, `Date_Added`, `Time_Added`) VALUES
(1, 'Elon', ' ', 'Musk', 48, 'Canadian', 'married', 'Silicon Valley, United States', 'SSS No. 728-626-090', '', '<ol>\r\n	<li>That I am a 4th year College student of Cronasia Foundation College, Inc., General Santos City, taking up Bachelor of Science in Criminology and a holder of a School ID duly issued by the said institution;</li>\r\n	<li>That sometime in December 2021, I noticed that the aforesaid school ID was no longer in my possession and control;</li>\r\n	<li>That despite diligent search and efforts had been exerted to locate the same could no longer be found;</li>\r\n	<li>That the aforesaid identification card was not confiscated by any legal authority nor used as security for payment of debts or other obligations;</li>\r\n	<li>That I am executing this affidavit to establish its loss and to support my request for replacement in lieu of the lost one and for whatever legal purposes it may serve best.</li>\r\n</ol>\r\n', '2023-02-22', '06:58:24'),
(2, 'Bill', ' ', 'Gates', 65, 'American', 'married', 'Brgy. San Juan, Padre Burgos, Southern Leyte', 'SSS No. 728-626-090', '', '<ol>\r\n	<li>That I am a 4th year College student of Cronasia Foundation College, Inc., General Santos City, taking up Bachelor of Science in Criminology and a holder of a School ID duly issued by the said institution;</li>\r\n	<li>That sometime in December 2021, I noticed that the aforesaid school ID was no longer in my possession and control;</li>\r\n	<li>That despite diligent search and efforts had been exerted to locate the same could no longer be found;</li>\r\n	<li>That the aforesaid identification card was not confiscated by any legal authority nor used as security for payment of debts or other obligations;</li>\r\n	<li>That I am executing this affidavit to establish its loss and to support my request for replacement in lieu of the lost one and for whatever legal purposes it may serve best.</li>\r\n</ol>\r\n', '2023-02-22', '07:19:11');

-- --------------------------------------------------------

--
-- Table structure for table `client_namelist_tbl`
--

CREATE TABLE `client_namelist_tbl` (
  `Id` int(11) NOT NULL,
  `Full_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client_namelist_tbl`
--

INSERT INTO `client_namelist_tbl` (`Id`, `Full_Name`) VALUES
(1, 'Elon   Musk'),
(2, 'Bill   Gates');

-- --------------------------------------------------------

--
-- Table structure for table `doctemplatesstructure_tbl`
--

CREATE TABLE `doctemplatesstructure_tbl` (
  `Id` int(11) NOT NULL,
  `Title_Id` int(11) NOT NULL,
  `Template_Form` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctemplatesstructure_tbl`
--

INSERT INTO `doctemplatesstructure_tbl` (`Id`, `Title_Id`, `Template_Form`) VALUES
(1, 1, '<div class=\"mb-3\">\n                                <input id = \"title-id\" class=\"form-control d-none\" type=\"text\" name=\"title-id\">\n                            </div>\n\n                            <div class=\"mb-3\" style=\"position:relative;\">\n                                <div>\n                                    <label for=\"\"><strong>Header #1</strong></label>\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\n                                </div>\n                                <textarea name=\"header[]\" id=\"header-1\"></textarea>\n                            </div>\n\n                            <div class=\"mb-3\" style=\"position:relative;\">\n                                <div>\n                                    <label for=\"\"><strong>Body #1</strong></label>\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\n                                </div>\n                                <textarea name=\"body[]\" id=\"body-1\"></textarea>\n                            </div>\n\n                            <div class=\"mb-3\" style=\"position:relative;\">\n                                <div>\n                                    <label for=\"\"><strong>Body #2</strong></label>\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\n                                </div>\n                                <textarea name=\"body[]\" id=\"body-2\"></textarea>\n                            </div>\n\n                            <div class=\"mb-3\" style=\"position:relative;\">\n                                <div>\n                                    <label for=\"\"><strong>Footer #1</strong></label>\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\n                                </div>\n                                <textarea name=\"footer[]\" id=\"footer-1\"></textarea>\n                            </div>'),
(2, 3, '<div class=\"mb-3\">\r\n                                <input id = \"title-id\" class=\"form-control d-none\" type=\"text\" name=\"title-id\">\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Header #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"header[]\" id=\"header-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #2</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-2\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Footer #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"footer[]\" id=\"footer-1\"></textarea>\r\n                            </div>'),
(3, 4, '<div class=\"mb-3\">\r\n                                <input id = \"title-id\" class=\"form-control d-none\" type=\"text\" name=\"title-id\">\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Header #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"header[]\" id=\"header-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #2</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-2\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Footer #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"footer[]\" id=\"footer-1\"></textarea>\r\n                            </div>'),
(4, 7, '							<div class=\"mb-3\">\r\n                                <input id = \"title-id\" class=\"form-control d-none\" type=\"text\" name=\"title-id\">\r\n                            </div>\r\n\r\n                            <div class=\"mb-3 d-none\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Header #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"header[]\" id=\"header-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #2</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-2\"></textarea>\r\n                            </div>\r\n							\r\n							<div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #3</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-3\"></textarea>\r\n                            </div>\r\n							\r\n							<div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #4</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-4\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #5</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-5\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #6</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-6\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Footer #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"footer[]\" id=\"footer-1\"></textarea>\r\n                            </div>'),
(5, 8, '							<div class=\"mb-3\">\r\n                                <input id = \"title-id\" class=\"form-control d-none\" type=\"text\" name=\"title-id\">\r\n                            </div>\r\n\r\n                            <div class=\"mb-3 d-none\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Header #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"header[]\" id=\"header-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-1\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #2</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-2\"></textarea>\r\n                            </div>\r\n							\r\n							<div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Body #3</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"body[]\" id=\"body-3\"></textarea>\r\n                            </div>\r\n\r\n                            <div class=\"mb-3\" style=\"position:relative;\">\r\n                                <div>\r\n                                    <label for=\"\"><strong>Footer #1</strong></label>\r\n                                    <div class=\"wrapper-001\" style=\"position:absolute;right:0;top:0;cursor:pointer;\"></div>\r\n                                </div>\r\n                                <textarea name=\"footer[]\" id=\"footer-1\"></textarea>\r\n                            </div>');

-- --------------------------------------------------------

--
-- Table structure for table `documents_tbl`
--

CREATE TABLE `documents_tbl` (
  `Id` int(11) NOT NULL,
  `Title_Id` int(11) NOT NULL,
  `Temp_Id` int(11) NOT NULL,
  `Client_Data_Id` int(11) NOT NULL,
  `Status` int(11) NOT NULL,
  `Doc_No` varchar(50) NOT NULL,
  `Page_No` varchar(50) NOT NULL,
  `Book_No` varchar(50) NOT NULL,
  `Series_of` varchar(50) NOT NULL,
  `Produced_By` varchar(100) NOT NULL,
  `Client_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `documents_title_tbl`
--

CREATE TABLE `documents_title_tbl` (
  `Id` int(11) NOT NULL,
  `Title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `documents_title_tbl`
--

INSERT INTO `documents_title_tbl` (`Id`, `Title`) VALUES
(1, 'Affidavit of Loss'),
(3, 'Affidavit of Discrepancy'),
(4, 'Affidavit of Undertaking'),
(7, 'Contract of Lease'),
(8, 'Special Power of Attorney');

-- --------------------------------------------------------

--
-- Table structure for table `doc_templates_tbl`
--

CREATE TABLE `doc_templates_tbl` (
  `Id` int(11) NOT NULL,
  `Title_Id` int(11) NOT NULL,
  `Header` text NOT NULL,
  `Body` text NOT NULL,
  `Footer` text NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment_tbl`
--

CREATE TABLE `payment_tbl` (
  `Id` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Recipient_Name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `Document_Title` text COLLATE utf8_unicode_ci NOT NULL,
  `Original_Amount` double NOT NULL,
  `Discount` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `Final_Amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_tbl`
--

INSERT INTO `payment_tbl` (`Id`, `Date`, `Recipient_Name`, `Document_Title`, `Original_Amount`, `Discount`, `Final_Amount`) VALUES
(1, '2023-02-22', 'Elon   Musk', 'Affidavit of Loss', 150, '0%', 150);

-- --------------------------------------------------------

--
-- Table structure for table `price_tbl`
--

CREATE TABLE `price_tbl` (
  `Id` int(11) NOT NULL,
  `Temp_Id` int(11) NOT NULL,
  `Title_Id` int(11) NOT NULL,
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `price_tbl`
--

INSERT INTO `price_tbl` (`Id`, `Temp_Id`, `Title_Id`, `Price`) VALUES
(1, 1, 1, 150);

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `Id` int(11) NOT NULL,
  `First_Name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `Last_Name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `User_Name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `User_Type` varchar(128) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`Id`, `First_Name`, `Last_Name`, `User_Name`, `Password`, `User_Type`) VALUES
(1, 'Gremar', 'Campilan', 'admin', 'admin123', 'Admin'),
(4, 'Jack', 'Ma', 'jackMa', '1234567890', 'Secretary');

-- --------------------------------------------------------

--
-- Table structure for table `year_tbl`
--

CREATE TABLE `year_tbl` (
  `Id` int(11) NOT NULL,
  `Year` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `year_tbl`
--

INSERT INTO `year_tbl` (`Id`, `Year`) VALUES
(1, '2018'),
(2, '2019'),
(3, '2020'),
(4, '2021'),
(8, '2022'),
(9, '2023');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client_data_structure_tbl`
--
ALTER TABLE `client_data_structure_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `client_data_tbl`
--
ALTER TABLE `client_data_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `client_namelist_tbl`
--
ALTER TABLE `client_namelist_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `doctemplatesstructure_tbl`
--
ALTER TABLE `doctemplatesstructure_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `documents_tbl`
--
ALTER TABLE `documents_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `documents_title_tbl`
--
ALTER TABLE `documents_title_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `doc_templates_tbl`
--
ALTER TABLE `doc_templates_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `payment_tbl`
--
ALTER TABLE `payment_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `price_tbl`
--
ALTER TABLE `price_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `year_tbl`
--
ALTER TABLE `year_tbl`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client_data_structure_tbl`
--
ALTER TABLE `client_data_structure_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `client_data_tbl`
--
ALTER TABLE `client_data_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `client_namelist_tbl`
--
ALTER TABLE `client_namelist_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctemplatesstructure_tbl`
--
ALTER TABLE `doctemplatesstructure_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `documents_tbl`
--
ALTER TABLE `documents_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `documents_title_tbl`
--
ALTER TABLE `documents_title_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doc_templates_tbl`
--
ALTER TABLE `doc_templates_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment_tbl`
--
ALTER TABLE `payment_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `price_tbl`
--
ALTER TABLE `price_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `year_tbl`
--
ALTER TABLE `year_tbl`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

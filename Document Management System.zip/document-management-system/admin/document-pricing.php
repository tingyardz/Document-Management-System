<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }

    $sql = "SELECT *, `doc_templates_tbl`.`Id` AS `temp_id` FROM `doc_templates_tbl` INNER JOIN `documents_title_tbl` ON `doc_templates_tbl`.`Title_Id` = `documents_title_tbl`.`Id` WHERE `Status` = '0'";
    $query = $connect->query($sql) or die($connect->error);

    $sql_1 = "SELECT *, `price_tbl`.`Id` AS `price_id` FROM `price_tbl` INNER JOIN `documents_title_tbl` ON `price_tbl`.`Title_Id` = `documents_title_tbl`.`Id`";
    $query_1 = $connect->query($sql_1) or die($connect->error);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Admin | DMS</title>
        <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../bootstrap/css/simple-datatables@latest.css">
        <link rel="stylesheet" href="../bootstrap/css/table.style.css">
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/all.min.css">
        <link rel="stylesheet" href="css/document-pricing.css">
        <script src="js/jquery.min.js"></script>

   </head>
    <body class="sb-nav-fixed">

        <?php require_once('top-bar.php'); ?>

        <div id="layoutSidenav">

            <!-- Navigation Bar -->
            <?php require_once('navbar.php'); ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Document Pricing</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home</li>
                            <li class="breadcrumb-item active">Document Pricing</li>
                        </ol>

                        <!-- Alert -->
                        <div id="processing-message-alert" class="alert d-none text-center" role="alert"></div>

                        <div class="row pb-5">
                            <div class="col-12 col-xl-6 col-lg-6">
                                <div class="bg-light p-2 border" style="height:365px;overflow-y:auto;position:relative;">
                                    <table class="table">
                                        <thead style="font-size:0.875rem;position:sticky;position:-webkit-sticky;top:-8px;background-color:rgb(220,220,220)">
                                            <tr>
                                                <th>Id</th>
                                                <th>Title</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbody_1" style="font-size: 0.875rem;">
                                            <?php
                                                while ($row = $query->fetch_assoc()) {
                                            ?>
                                            <tr>
                                                <td><?php echo $row['temp_id'] ?></td>
                                                <td><?php echo $row['Title'] ?></td>
                                                <td><button onclick="getTemplatesData(<?php echo $row['temp_id'] ?>)" class="setPriceBtn" data-bs-toggle="modal" data-bs-target="#set-document-price-modal">Set Price</button></td>
                                            </tr>
                                            <?php
                                                }
                                            ?>
                                            <?php
                                                if($query->num_rows == 0){
                                            ?>
                                            <tr>
                                                <td class="dataTables-empty" colspan="3">No entries found</td>
                                            </tr>
                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="col-12 col-xl-6 col-lg-6">
                                <div class="bg-light p-2">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Title</th>
                                                <th>Price</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                while ($row_1 = $query_1->fetch_assoc()) {
                                            ?>
                                            <tr>
                                                <td><?php echo $row_1['price_id']; ?></td>
                                                <td><?php echo $row_1['Title']; ?></td>
                                                <td>&#8369;<?php echo $row_1['Price']; ?></td>
                                                <td>
                                                    <i onclick="updateDocPrice(<?php echo $row_1['price_id']; ?>)" class="fa-solid fa-pen-to-square icon-000 text-primary" title="Update" data-bs-toggle="modal" data-bs-target="#update-document-price-modal"></i>
                                                    <i onclick="removeData(<?php echo $row_1['Temp_Id']; ?>)" class="fa-solid fa-trash icon-000 text-danger" title="Remove"></i>
                                                </td>
                                            </tr>
                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </main>
            </div>
        </div>

        <!--Set Price Modal -->
        <div class="modal fade" id="set-document-price-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Set Document Price</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="../form-process.php" method="POST">
                    <div class="mb-2 d-none">
                        <label for="">Temp Id</label>
                        <input id="inputTempId" class="form-control" name="temp-id" type="number">
                    </div>
                    <div class="mb-2 d-none">
                        <label for="">Title Id</label>
                        <input id="inputTitleId" class="form-control" name="title-id" type="number">
                    </div>
                    <div class="mb-2">
                        <label for="">Document Title</label>
                        <input id="inputDocumentTitle" class="form-control bg-light" type="text" name="document-title" readonly>
                    </div>
                    <div class="mb-2">
                        <label for="">Price</label>
                        <input class="form-control" name="price" type="number" step="0.01" required>
                    </div>
              </div>
              <div class="modal-footer mb-2">
                <button type="type" name="submit-document-price" class="btn btn-primary w-75" style="margin:auto;">Submit</button>
                </form>
            </div>
            </div>
          </div>
        </div>

        <!-- Update Price Modal -->
        <div class="modal fade" id="update-document-price-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Update Document Price</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="../form-process.php" method="POST">
                    <div class="mb-2 d-none">
                        <label for="">Id</label>
                        <input id="update-inputDocumentId" class="form-control" name="id" type="number">
                    </div>
                    <div class="mb-2">
                        <label for="">Document Title</label>
                        <div id="update-displayDocumentTitle" class="border p-2 rounded"></div>
                    </div>
                    <div class="mb-2">
                        <label for="">Price</label>
                        <input id="update-price" class="form-control" name="price" type="number" step="0.01" required>
                    </div>
              </div>
              <div class="modal-footer mb-2">
                <button type="type" name="submit-new-document-price" class="btn btn-primary w-75" style="margin:auto;">Update</button>
                </form>
            </div>
            </div>
          </div>
        </div>


        <!-- Javascript -->
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="../bootstrap/js/datatables-simple-demo.js"></script>
        <script src="../bootstrap/js/simple-datatables@latest.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/document-pricing.js"></script>
    </body>
</html>

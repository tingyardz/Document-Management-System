$(document).ready(function(){
  $.ajax({
    type: 'POST',
    url: '../ajax-process.php',
    data: {
      action: 'getTheTop5MostRequestedDocuments'
    }
  }).then(function(response){
    top5Documents = JSON.parse(response);
  });
});

let checkTop5Documents = setInterval(() => {

  if(top5Documents.length > 0){

    clearInterval(checkTop5Documents);

    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#292b2c';

    var ctx = document.getElementById("top5-chart");
    var myPieChart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: [top5Documents[0][0], top5Documents[1][0], top5Documents[2][0], top5Documents[3][0], top5Documents[4][0]],
        datasets: [{
          data: [top5Documents[0][1], top5Documents[1][1], top5Documents[2][1], top5Documents[3][1], top5Documents[4][1]],
          backgroundColor: ['#007bff', '#dc3545', '#ffc107', '#28a745', 'gray'],
        }],
      },
      options: {
        title:{
          display:true,
          text:'Top 5 Most Requested Documents',
          fontSize:18,
          fontColor:'#28a745'
        },
        legend:{
          display:true,
          position:'top',
          labels:{
            fontColor:'#000'
          }
        },
        tooltips:{
          enabled:true
        }
      }

    });

  }

}, 500);


//ajax
let recheckTotalDocuments = setInterval(() => {
  
  if(totalDocuments_1 != getTotalDocuments){

    totalDocuments_1 = getTotalDocuments;

    $(document).ready(function(){
      $.ajax({
        type: 'POST',
        url: '../ajax-process.php',
        data: {
          action: 'getTheTop5MostRequestedDocuments'
        }
      }).then(function(response){
        top5Documents = JSON.parse(response);

        $('#chart_3').empty();
        $('#chart_3').html("<canvas id=\"top5-chart\"></canvas>");

        // Set new default font family and font color to mimic Bootstrap's default styling
        Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
        Chart.defaults.global.defaultFontColor = '#292b2c';
    
        var ctx = document.getElementById("top5-chart");
        var myPieChart = new Chart(ctx, {
          type: 'pie',
          data: {
            labels: [top5Documents[0][0], top5Documents[1][0], top5Documents[2][0], top5Documents[3][0], top5Documents[4][0]],
            datasets: [{
              data: [top5Documents[0][1], top5Documents[1][1], top5Documents[2][1], top5Documents[3][1], top5Documents[4][1]],
              backgroundColor: ['#007bff', '#dc3545', '#ffc107', '#28a745', 'gray'],
            }],
          },
          options: {
            title:{
              display:true,
              text:'Top 5 Most Requested Documents',
              fontSize:18,
              fontColor:'#28a745'
            },
            legend:{
              display:true,
              position:'top',
              labels:{
                fontColor:'#000'
              }
            },
            tooltips:{
              enabled:true
            }
          }
    
        });

      });
    });

  }
}, 10000);
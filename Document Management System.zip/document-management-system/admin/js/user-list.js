function validation_1(){
    let password = document.getElementById('inputPassword').value;
    let confirmPassword = document.getElementById('inputPasswordConfirm').value;
    if(password !== confirmPassword){
        $('#message-alert').removeClass('d-none');
        setTimeout(function(){
            $('#message-alert').addClass('d-none');
        },5000);
        return false;
    }
}

function validation_2(){
    let password = document.getElementById('update-inputPassword').value;
    let confirmPassword = document.getElementById('update-inputPasswordConfirm').value;
    if(password !== confirmPassword){
        $('#update-message-alert').removeClass('d-none');
        setTimeout(function(){
            $('#update-message-alert').addClass('d-none');
        },5000);
        return false;
    }
}

function updateUser(id){
    let userId = id;
    $(document).ready(function(){
        $.ajax({
            type: 'POST',
            url: '../ajax-process.php',
            data: {
                action : 'getUserData',
                id : userId
            }
        }).then(function(response){
            let data = JSON.parse(response);
            $('#update-inputUserId').val(data.Id);
            $('#update-inputFirstName').val(data.First_Name);
            $('#update-inputLastName').val(data.Last_Name);
            $('#update-inputUsername').val(data.User_Name);
            $('#update-inputPassword').val(data.Password);
            switch(data.User_Type){
                case "Secretary":
                    $('#update-user-type').html(
                        '<option value="Secretary" selected>Secretary</option>' 
                        +
                        '<option value="Cashier">Cashier</option>'
                        );
                    break; 
                case "Cashier" :
                    $('#update-user-type').html(
                        '<option value="Secretary">Secretary</option>' 
                        +
                        '<option value="Cashier" selected>Cashier</option>'
                        );
                    break; 
            }
        }).fail(function(response){
            alert("There was a problem with this function!");
        });
    });
}

function removeUser(id){
    let permission = window.confirm("Are you sure to remove this user?");
    if(permission){
        $(document).ready(function(){
            $.ajax({
                type: 'POST',
                url: '../ajax-process.php',
                data: {
                    action: 'removeUser',
                    userId: id
                }
            }).then(function(response){
                if(response === "Success"){
                    window.location.href="user-list.php";
                }
                else if(response === "Failed"){
                    alert("There was a problem with your server!");
                }
            }).fail(function(response){
                alert(response.status);
            });
        });
    }
}

//check alert message
$(document).ready(function(){
    $.post(
        '../ajax-process.php',
        {
            action: 'getProcessMessageAlert'
        },
        function(data){
            if(data){
                let value = JSON.parse(data);
                $('#processing-message-alert').removeClass('d-none');
                $('#processing-message-alert').addClass(value[1]);
                $('#processing-message-alert').html(value[0]);
                setTimeout(() => {
                    $('#processing-message-alert').addClass('d-none');
                }, 5000);
            }
        }
    );
});
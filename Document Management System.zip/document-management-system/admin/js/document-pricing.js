function updateDocPrice(id){
    $(document).ready(function(){
        $.ajax({
            type: 'POST',
            url: '../ajax-process.php',
            data: {
                action: 'getDocumentPrice',
                documentId: id
            }
        }).then(function(response){
            let data = JSON.parse(response);
            document.getElementById('update-displayDocumentTitle').innerHTML = data.Title;
            document.getElementById('update-inputDocumentId').value = data.Id;
            document.getElementById('update-price').value = data.Price;
        }).fail(function(response){
            alert(response.status);
        });
        
    });
}

function getTemplatesData(id){
    $.post(
        '../ajax-process.php',
        {
            action : "getTemplatesData01",
            tempId : id
        },
        function(data){
            var value = JSON.parse(data);
            $('#inputTempId').val(value[0]);
            $('#inputTitleId').val(value[1]);
            $('#inputDocumentTitle').val(value[2]);
        }
    );
}

function removeData(id){
    let permission = window.confirm("Are you sure to remove this data?");
    if(permission){
        $(document).ready(function(){
            $.ajax({
                type: 'POST',
                url: '../ajax-process.php',
                data: {
                    action: 'removeDataFromPriceTable',
                    dataId: id
                }
            }).then(function(response){
                if(response === "Success"){
                    window.location.href="document-pricing.php";
                }
                else if(response === "Failed"){
                    alert("There was a problem with your server!");
                }
                else if(response === "Restricted"){
                    window.location.href="document-pricing.php";
                }
            }).fail(function(response){
                alert(response.status);
            });
        });
    }
}

//check alert message
$(document).ready(function(){
    $.post(
        '../ajax-process.php',
        {
            action: 'getProcessMessageAlert'
        },
        function(data){
            if(data){
                let value = JSON.parse(data);
                $('#processing-message-alert').removeClass('d-none');
                $('#processing-message-alert').addClass(value[1]);
                $('#processing-message-alert').html(value[0]);
                setTimeout(() => {
                    $('#processing-message-alert').addClass('d-none');
                }, 5000);
            }
        }
    );

    // higlights active module
    $('#documents-dropDown').removeClass('collapsed');
    $('#documents-dropDown').attr('aria-expanded', true);
    $('#collapseDocuments').addClass('show');
});
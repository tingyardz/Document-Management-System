$(document).ready(function(){
  //get total income per month
    $.ajax({
      type: 'POST',
      url: '../ajax-process.php',
      data: {
        action: 'getTotalIncomePerMonth',
        selectedYear: currentYear
      }
    }).then(function(response){
      totalIncomePerMonth = JSON.parse(response);
    }).fail(function(response){
      alert("Error: "+response);
    });

  //get overall income
    $.ajax({
      type: 'POST',
      url: '../ajax-process.php',
      data: {
        action: 'getOverallIncome'
      }
    }).then(function(response){
      overalIncome = response;
    }).fail(function(response){
      alert("Error: "+response);
    });


});

let checkTotalIncomePerMonth = setInterval(() => {
  if(totalIncomePerMonth.length > 0){
    clearInterval(checkTotalIncomePerMonth);
    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#292b2c';

    // Bar Chart Example
    var ctx = document.getElementById("total-income-chart");
    var myLineChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ["January","February","March","April","May","June","July","August","September","October","November","December"],
        datasets: [{
          label: "Total Income",
          backgroundColor: "#dc3545",
          borderColor: "rgba(2,117,216,1)",
          data: [totalIncomePerMonth[0], totalIncomePerMonth[1], totalIncomePerMonth[2], totalIncomePerMonth[3], totalIncomePerMonth[4], totalIncomePerMonth[5], totalIncomePerMonth[6], totalIncomePerMonth[7], totalIncomePerMonth[8], totalIncomePerMonth[9], totalIncomePerMonth[10], totalIncomePerMonth[11]],
        }],
      },
      options: {
        title:{
          display:true,
          text:'Total Income ('+selectedYear+')',
          fontSize:18,
          fontColor:'#dc3545'
        },
        scales: {
          xAxes: [{
            time: {
              unit: 'month'
            },
            gridLines: {
              display: false
            },
            ticks: {
              maxTicksLimit: 6
            }
          }],
          yAxes: [{
            ticks: {
              min: 0,
              // max: 15000,
              maxTicksLimit: 5
            },
            gridLines: {
              display: true
            }
          }],
        },
        legend:{
          display:true,
          position:'top',
          labels:{
            fontColor:'#dc3545'
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });

  }
}, 500);

//ajax
// let recheckCurrentIncome = setInterval(() => {
//     //get overall income
//     $.ajax({
//       type: 'POST',
//       url: '../ajax-process.php',
//       data: {
//         action: 'getOverallIncome'
//       }
//     }).then(function(response){
//       if(overalIncome != response && specificYear == currentYear){
//         overalIncome = response;

//         totalIncomePerMonth = [];
//         //get total income per month
//         $.ajax({
//           type: 'POST',
//           url: '../ajax-process.php',
//           data: {
//             action: 'getTotalIncomePerMonth',
//             selectedYear: currentYear
//           }
//         }).then(function(response){
//           totalIncomePerMonth = JSON.parse(response);
//         }).fail(function(response){
//           alert("Error: "+response);
//         });

//         $('#chart_2').empty();
//         $('#chart_2').html("<canvas id=\"total-income-chart\"></canvas>");

//         let checkTotalIncomePerMonth = setInterval(() => {
//           if(totalIncomePerMonth.length > 0){
//             clearInterval(checkTotalIncomePerMonth);
//             // Set new default font family and font color to mimic Bootstrap's default styling
//             Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
//             Chart.defaults.global.defaultFontColor = '#292b2c';
        
//             var ctx = document.getElementById("total-income-chart");
//             var myLineChart = new Chart(ctx, {
//               type: 'bar',
//               data: {
//                 labels: ["January","February","March","April","May","June","July","August","September","October","November","December"],
//                 datasets: [{
//                   label: "Total Income",
//                   backgroundColor: "#dc3545",
//                   borderColor: "rgba(2,117,216,1)",
//                   data: [totalIncomePerMonth[0], totalIncomePerMonth[1], totalIncomePerMonth[2], totalIncomePerMonth[3], totalIncomePerMonth[4], totalIncomePerMonth[5], totalIncomePerMonth[6], totalIncomePerMonth[7], totalIncomePerMonth[8], totalIncomePerMonth[9], totalIncomePerMonth[10], totalIncomePerMonth[11]],
//                 }],
//               },
//               options: {
//                 title:{
//                   display:true,
//                   text:'Total Income ('+selectedYear+')',
//                   fontSize:18,
//                   fontColor:'#dc3545'
//                 },
//                 scales: {
//                   xAxes: [{
//                     time: {
//                       unit: 'month'
//                     },
//                     gridLines: {
//                       display: false
//                     },
//                     ticks: {
//                       maxTicksLimit: 6
//                     }
//                   }],
//                   yAxes: [{
//                     ticks: {
//                       min: 0,
//                       // max: 15000,
//                       maxTicksLimit: 5
//                     },
//                     gridLines: {
//                       display: true
//                     }
//                   }],
//                 },
//                 legend:{
//                   display:true,
//                   position:'top',
//                   labels:{
//                     fontColor:'#dc3545'
//                   }
//                 },
//                 tooltips:{
//                   enabled:true
//                 }
//               }
//             });
        
//           }
//         }, 500);

//       }
//     }).fail(function(response){
//       alert("Error: "+response);
//     });
  
// }, 10000);

//select Year
$(document).ready(function(){
  $('#selector_2-chart').on('change',function(){
    specificYear = this.value
      //get total income per month
      $.ajax({
        type: 'POST',
        url: '../ajax-process.php',
        data: {
          action: 'getTotalIncomePerMonth',
          selectedYear: specificYear
        }
      }).then(function(response){
        totalIncomePerMonth = [];
        totalIncomePerMonth = JSON.parse(response);

        // Set new default font family and font color to mimic Bootstrap's default styling
        Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
        Chart.defaults.global.defaultFontColor = '#292b2c';
    
        // Bar Chart Example
        var ctx = document.getElementById("total-income-chart");
        var myLineChart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: ["January","February","March","April","May","June","July","August","September","October","November","December"],
            datasets: [{
              label: "Total Income",
              backgroundColor: "#dc3545",
              borderColor: "rgba(2,117,216,1)",
              data: [totalIncomePerMonth[0], totalIncomePerMonth[1], totalIncomePerMonth[2], totalIncomePerMonth[3], totalIncomePerMonth[4], totalIncomePerMonth[5], totalIncomePerMonth[6], totalIncomePerMonth[7], totalIncomePerMonth[8], totalIncomePerMonth[9], totalIncomePerMonth[10], totalIncomePerMonth[11]],
            }],
          },
          options: {
            title:{
              display:true,
              text:'Total Income ('+specificYear+')',
              fontSize:18,
              fontColor:'#dc3545'
            },
            scales: {
              xAxes: [{
                time: {
                  unit: 'month'
                },
                gridLines: {
                  display: false
                },
                ticks: {
                  maxTicksLimit: 6
                }
              }],
              yAxes: [{
                ticks: {
                  min: 0,
                  // max: 15000,
                  maxTicksLimit: 5
                },
                gridLines: {
                  display: true
                }
              }],
            },
            legend:{
              display:true,
              position:'top',
              labels:{
                fontColor:'#dc3545'
              }
            },
            tooltips:{
              enabled:true
            }
          }
        });

      }).fail(function(response){
        alert("Error: "+response);
      });
  });
});
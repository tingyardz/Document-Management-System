
$(document).ready(function(){

  //checking all passed years
  $.post(
      '../ajax-process.php',
      {
          action: 'getAllPassingYears',
          currentYear: currentYear
      },
      function(data){
          let value = JSON.parse(data);
          value.forEach(element => {
              if(currentYear == element){
                  $('.selector_1-chart').prepend("<option value='"+element+"' selected>"+"Year "+element+"</option>");
              }
              else{
                  $('.selector_1-chart').prepend("<option value='"+element+"'>"+"Year "+element+"</option>");
              }
          });
      }
  );

  //get total documents for this year
  $.post(
    '../ajax-process.php',
    {
      action: 'getTotalDocumentsThisYear',
      selectedYear: selectedYear
    },
    function(data){
      totalDocumentsPerMonth = JSON.parse(data);
    }
  );

  // get total number of documents
  $.ajax({
    type: 'POST',
    url: '../ajax-process.php',
    data: {
      action: 'getNumberOfDataFromDocumentsTable'
    }
  }).then(function(response){
    getTotalDocuments = response;
    totalDocuments_1 = getTotalDocuments;
  }).fail(function(response){
    alert("Error: "+response.status);
  });

});

let checktotalDocumentsPerMonth = setInterval(() => {
  if(totalDocumentsPerMonth.length > 0){
    clearInterval(checktotalDocumentsPerMonth);

    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#292b2c';

    var ctx = document.getElementById("number-of-documents-created-chart");
    var myLineChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ["January","February","March","April","May","June","July","August","September","October","November","December"],
        datasets: [{
          label: "Total Documents",
          lineTension: 0.3,
          backgroundColor: "rgba(2,117,216,0.2)",
          borderColor: "rgba(2,117,216,1)",
          pointRadius: 5,
          pointBackgroundColor: "rgba(2,117,216,1)",
          pointBorderColor: "rgba(255,255,255,0.8)",
          pointHoverRadius: 5,
          pointHoverBackgroundColor: "rgba(2,117,216,1)",
          pointHitRadius: 50,
          pointBorderWidth: 2,
          data: [totalDocumentsPerMonth[0], totalDocumentsPerMonth[1], totalDocumentsPerMonth[2], totalDocumentsPerMonth[3], totalDocumentsPerMonth[4], totalDocumentsPerMonth[5], totalDocumentsPerMonth[6], totalDocumentsPerMonth[7], totalDocumentsPerMonth[8], totalDocumentsPerMonth[9], totalDocumentsPerMonth[10], totalDocumentsPerMonth[11]],
        }],
      },
      options: {
        title:{
          display:true,
          text:'Total Documents ('+selectedYear+')',
          fontSize:18,
          fontColor:'rgb(0,100,255)'
        },
        scales: {
          xAxes: [{
            time: {
              unit: 'date'
            },
            gridLines: {
              display: false
            },
            ticks: {
              maxTicksLimit: 6
            }
          }],
          yAxes: [{
            ticks: {
              min: 0,
              // max: 10,
              maxTicksLimit: 5
            },
            gridLines: {
              color: "rgba(0, 0, 0, .125)",
            }
          }],
        },
        legend:{
          display:true,
          position:'top',
          labels:{
            fontColor:'#000'
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });

  }
}, 500);

// //ajax
// setInterval(() => {
//   if(selectedYear == currentYear){
//     $.ajax({
//       type: 'POST',
//       url: '../ajax-process.php',
//       data: {
//         action: 'getNumberOfDataFromDocumentsTable'
//       }
//     }).then(function(response){
//       if(getTotalDocuments != response){
//         $('#chart_1').empty();
//         $('#chart_1').html("<canvas id=\"number-of-documents-created-chart\"></canvas>");
//         totalDocumentsPerMonth = [];
//         //get total documents for this year
//         $.post(
//           '../ajax-process.php',
//           {
//             action: 'getTotalDocumentsThisYear',
//             selectedYear: selectedYear
//           },
//           function(data){
//             totalDocumentsPerMonth = JSON.parse(data);
//           }
//         );
//         let checktotalDocumentsPerMonth = setInterval(() => {
//           if(totalDocumentsPerMonth.length > 0){
//             clearInterval(checktotalDocumentsPerMonth);

//             // Set new default font family and font color to mimic Bootstrap's default styling
//             Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
//             Chart.defaults.global.defaultFontColor = '#292b2c';

//             var ctx = document.getElementById("number-of-documents-created-chart");
//             var myLineChart = new Chart(ctx, {
//               type: 'line',
//               data: {
//                 labels: ["January","February","March","April","May","June","July","August","September","October","November","December"],
//                 datasets: [{
//                   label: "Total Documents",
//                   lineTension: 0.3,
//                   backgroundColor: "rgba(2,117,216,0.2)",
//                   borderColor: "rgba(2,117,216,1)",
//                   pointRadius: 5,
//                   pointBackgroundColor: "rgba(2,117,216,1)",
//                   pointBorderColor: "rgba(255,255,255,0.8)",
//                   pointHoverRadius: 5,
//                   pointHoverBackgroundColor: "rgba(2,117,216,1)",
//                   pointHitRadius: 50,
//                   pointBorderWidth: 2,
//                   data: [totalDocumentsPerMonth[0], totalDocumentsPerMonth[1], totalDocumentsPerMonth[2], totalDocumentsPerMonth[3], totalDocumentsPerMonth[4], totalDocumentsPerMonth[5], totalDocumentsPerMonth[6], totalDocumentsPerMonth[7], totalDocumentsPerMonth[8], totalDocumentsPerMonth[9], totalDocumentsPerMonth[10], totalDocumentsPerMonth[11]],
//                 }],
//               },
//               options: {
//                 title:{
//                   display:true,
//                   text:'Total Documents ('+selectedYear+')',
//                   fontSize:18,
//                   fontColor:'rgb(0,100,255)'
//                 },
//                 scales: {
//                   xAxes: [{
//                     time: {
//                       unit: 'date'
//                     },
//                     gridLines: {
//                       display: false
//                     },
//                     ticks: {
//                       maxTicksLimit: 6
//                     }
//                   }],
//                   yAxes: [{
//                     ticks: {
//                       min: 0,
//                       // max: 10,
//                       maxTicksLimit: 5
//                     },
//                     gridLines: {
//                       color: "rgba(0, 0, 0, .125)",
//                     }
//                   }],
//                 },
//                 legend:{
//                   display:true,
//                   position:'top',
//                   labels:{
//                     fontColor:'#000'
//                   }
//                 },
//                 layout:{
//                   padding:{
//                     left:50,
//                     right:0,
//                     bottom:0,
//                     top:0
//                   }
//                 },
//                 tooltips:{
//                   enabled:true
//                 }
//               }
//             });
        
//           }
//         }, 500);
//       }
//       getTotalDocuments = response;
//     }).fail(function(response){
//       alert("Error: "+response.status);
//     });
//   }
// }, 10000);

$('#selector_1-chart').on('change',function(){
    selectedYear = this.value;
    $('#chart_1').empty();
    $('#chart_1').html("<canvas id=\"number-of-documents-created-chart\"></canvas>");
    //get total documents for this year
    $.post(
      '../ajax-process.php',
      {
        action: 'getTotalDocumentsThisYear',
        selectedYear: selectedYear
      },
      function(data){
        totalDocumentsPerMonth = JSON.parse(data);

        // Set new default font family and font color to mimic Bootstrap's default styling
        Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
        Chart.defaults.global.defaultFontColor = '#292b2c';

        var ctx = document.getElementById("number-of-documents-created-chart");
        var myLineChart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: ["January","February","March","April","May","June","July","August","September","October","November","December"],
            datasets: [{
              label: "Total Documents",
              lineTension: 0.3,
              backgroundColor: "rgba(2,117,216,0.2)",
              borderColor: "rgba(2,117,216,1)",
              pointRadius: 5,
              pointBackgroundColor: "rgba(2,117,216,1)",
              pointBorderColor: "rgba(255,255,255,0.8)",
              pointHoverRadius: 5,
              pointHoverBackgroundColor: "rgba(2,117,216,1)",
              pointHitRadius: 50,
              pointBorderWidth: 2,
              data: [totalDocumentsPerMonth[0], totalDocumentsPerMonth[1], totalDocumentsPerMonth[2], totalDocumentsPerMonth[3], totalDocumentsPerMonth[4], totalDocumentsPerMonth[5], totalDocumentsPerMonth[6], totalDocumentsPerMonth[7], totalDocumentsPerMonth[8], totalDocumentsPerMonth[9], totalDocumentsPerMonth[10], totalDocumentsPerMonth[11]],
            }],
          },
          options: {
            title:{
              display:true,
              text:'Total Documents ('+selectedYear+')',
              fontSize:18,
              fontColor:'rgb(0,100,255)'
            },
            scales: {
              xAxes: [{
                time: {
                  unit: 'date'
                },
                gridLines: {
                  display: false
                },
                ticks: {
                  maxTicksLimit: 6
                }
              }],
              yAxes: [{
                ticks: {
                  min: 0,
                  // max: 10,
                  maxTicksLimit: 5
                },
                gridLines: {
                  color: "rgba(0, 0, 0, .125)",
                }
              }],
            },
            legend:{
              display:true,
              position:'top',
              labels:{
                fontColor:'#000'
              }
            },
            layout:{
              padding:{
                left:50,
                right:0,
                bottom:0,
                top:0
              }
            },
            tooltips:{
              enabled:true
            }
          }
        });
      }
    );
});
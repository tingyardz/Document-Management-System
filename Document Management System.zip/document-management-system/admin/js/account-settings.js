function validateForm() {
    let password = document.querySelector('#inputPassword').value;
    let confirmPassword = document.querySelector('#inputPasswordConfirm').value;
    if(password !== confirmPassword){
        document.querySelector('#message-alert').style = "display:block;";
        return false
    }
}
//dashboard variables
let totalDocuments;
let totalDocumentsToday;
let totalIncomeToday;

//chart documents variables
let date = new Date();
let currentYear = date.getFullYear();
let selectedYear = currentYear;
let totalDocumentsPerMonth = [];
let getTotalDocuments;

//chart income variables
let totalIncomePerMonth = [];
let overalIncome;
let specificYear = currentYear;

//chart top 5 variables
let totalDocuments_1;
let top5Documents = [];

$(document).ready(function(){
    $.post(
        '../ajax-process.php',
        {
            action: 'getAllStats'
        },
        function(data){
            let stats = JSON.parse(data);
            if(stats.totalDocuments >= 100){
                $('#chart_3_wrapper').removeClass('d-none');
                $('body').append("<script src=\"js/chart-top5.js\"></script>");
            }
            $('#overall-documents').html(stats.totalDocuments);
            $('#total-documents-today').html(stats.totalDocumentsToday);
            const formatter = new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'PHP',
              });
            $('#total-income-today').html(formatter.format(stats.totalIncomeToday));
        }
    );
});

$(document).ready(function(){
    $('#over-all-documents').on('click',function(){
        $.post(
            '../ajax-process.php',
            {
                action : 'getOverallDocuments'
            },
            function(data){
                $('#tbody-01').html(data);
            }
        );
    });

    $('#total-documents-today-02').on('click',function(){
        $.post(
            '../ajax-process.php',
            {
                action : 'getTotalDocumentsToday'
            },
            function(data){
                console.log(data);
                $('#tbody-02').html(data);
            }
        );
    });
});
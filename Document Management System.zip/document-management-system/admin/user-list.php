<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }

    //get user data
    $sql = "SELECT * FROM `user_tbl`";
    $query = $connect->query($sql) or die($connect->error);
    $row = $query->fetch_assoc();
    $total = $query->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Admin | DMS</title>
        <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../bootstrap/css/simple-datatables@latest.css">
        <link rel="stylesheet" href="../bootstrap/css/table.style.css">
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/all.min.css">
        <link rel="stylesheet" href="css/user-list.css">
        <script src="js/jquery.min.js"></script>

   </head>
    <body class="sb-nav-fixed">

        <?php require_once('top-bar.php'); ?>

        <div id="layoutSidenav">

            <!-- Navigation Bar -->
            <?php require_once('navbar.php'); ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">User List</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home</li>
                            <li class="breadcrumb-item active">User List</li>
                        </ol>

                        <!-- Alert -->
                        <div id="processing-message-alert" class="alert d-none text-center" role="alert"></div>

                        <div class="row bg-light">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <div class="p-1" style="display:inline-block;"><i class="fas fa-table me-1"></i>User List</div>
                                    <div style="display:inline-block;position:absolute;right:30px;"><button id="addTempBtn" class="p-1 ps-2 pe-2 border-0 bg-primary text-light rounded" data-bs-toggle="modal" data-bs-target="#addNewUser"><i class="fa-solid fa-plus"></i> Add New User</button></div>
                                </div>
                                <div class="card-body" style="position:relative;">
                                    <table id="datatablesSimple">
                                        <thead>

                                            <tr>
                                                <th>Id</th>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>User Type</th>
                                                <th>Username</th>
                                                <th>Password</th>
                                                <th>Action</th>
                                            </tr>

                                        </thead>

                                        <tbody>
                                            <?php
                                                if($total){
                                                    do{
                                                        if($row['User_Type'] !== "Admin"){
                                            ?>
                                            <tr>
                                                <td><?php echo $row['Id']; ?></td>
                                                <td><?php echo $row['First_Name']; ?></td>
                                                <td><?php echo $row['Last_Name']; ?></td>
                                                <td><?php echo $row['User_Type']; ?></td>
                                                <td><?php echo $row['User_Name']; ?></td>
                                                <td><?php echo $row['Password']; ?></td>
                                                <td>
                                                    <i onclick="updateUser(<?php echo $row['Id']; ?>)" class="fa-solid fa-pen-to-square icon-000 text-primary" title="Update" data-bs-toggle="modal" data-bs-target="#update-user-modal"></i>
                                                    <i onclick="removeUser(<?php echo $row['Id']; ?>)" class="fa-solid fa-trash icon-000 text-danger" title="Remove"></i>
                                                </td>
                                            </tr>
                                            <?php
                                                        }
                                                    }while($row = $query->fetch_assoc());
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                        </div>

                    </div>
                </main>
            </div>
        </div>
    
        <!-- Modal -->
        <div class="modal fade" id="addNewUser" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog" style="max-width:60%;">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="staticBackdropLabel">Add New User</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                      <form action="../form-process.php" method="POST">
                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="inputFirstName" type="text" name="first-name" placeholder="Enter your first name" required/>
                                      <label for="inputFirstName">First name</label>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="inputUsername" type="text" name="username" placeholder="Enter username" required/>
                                      <label for="inputUsername">Username</label>
                                  </div>
                              </div>
                          </div>

                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <div class="form-floating">
                                      <input class="form-control" id="inputLastName" type="text" name="last-name" placeholder="Enter your last name" required/>
                                      <label for="inputLastName">Last name</label>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="inputPassword" type="password" name="password" placeholder="Create a password" required/>
                                      <label for="inputPassword">Password</label>
                                  </div>
                              </div>
                          </div>

                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <select class="form-select" name="user-type" id="user-type" name="user-type" required>
                                          <option value="Secretary">Secretary</option>
                                          <option value="Cashier">Cashier</option>
                                      </select>
                                      <label for="user-type">User Type</label>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="inputPasswordConfirm" type="password" name="confirm-password" placeholder="Confirm password" required/>
                                      <label for="inputPasswordConfirm">Confirm Password</label>
                                  </div>
                              </div>
                          </div>


                      <div id="message-alert" class="bg-danger text-center text-light p-2 d-none"><h6 class="m-0">Please recheck your password!</h6></div>

                </div>
                <div class="modal-footer mb-2">
                  <button onclick="return validation_1()" type="submit" name="add-new-user" class="btn btn-primary w-50" style="margin:auto;">Add New User</button>
                  </form>
              </div>
              </div>
            </div>
        </div>

        <div class="modal fade" id="update-user-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog" style="max-width:60%;">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="staticBackdropLabel">Update User</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                      <form action="../form-process.php" method="POST">
                          <input id="update-inputUserId" class="form-control mb-3 d-none" type="number" name="id">
                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="update-inputFirstName" type="text" name="first-name" placeholder="Enter your first name" required/>
                                      <label for="update-inputFirstName">First name</label>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="update-inputUsername" type="text" name="username" placeholder="Enter username" required/>
                                      <label for="update-inputUsername">Username</label>
                                  </div>
                              </div>
                          </div>

                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <div class="form-floating">
                                      <input class="form-control" id="update-inputLastName" type="text" name="last-name" placeholder="Enter your last name" required/>
                                      <label for="update-inputLastName">Last name</label>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="update-inputPassword" type="password" name="password" placeholder="Create a password" required/>
                                      <label for="update-inputPassword">Password</label>
                                  </div>
                              </div>
                          </div>

                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <select class="form-select" name="user-type" id="update-user-type" name="user-type" required>
                                          
                                      </select>
                                      <label for="update-user-type">User Type</label>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <div class="form-floating mb-3 mb-md-0">
                                      <input class="form-control" id="update-inputPasswordConfirm" type="password" name="confirm-password" placeholder="Confirm password" required/>
                                      <label for="update-inputPasswordConfirm">Confirm Password</label>
                                  </div>
                              </div>
                          </div>


                      <div id="update-message-alert" class="bg-danger text-center text-light p-2 d-none"><h6 class="m-0">Please recheck your password!</h6></div>

                </div>
                <div class="modal-footer mb-2">
                  <button onclick="return validation_2()" type="submit" name="update-user" class="btn btn-primary w-50" style="margin:auto;">Update User</button>
                  </form>
              </div>
              </div>
            </div>
        </div>


        <!-- Javascript -->
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="../bootstrap/js/datatables-simple-demo.js"></script>
        <script src="../bootstrap/js/simple-datatables@latest.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/user-list.js"></script>
    </body>
</html>

<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">

                <a href="index.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="dashboard-tab">
                        <i class="fa-solid fa-chart-line"></i>
                        Dashboard
                    </div>
                </a>

                <a id="documents-dropDown" class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseDocuments" aria-expanded="true" aria-controls="collapseDocuments">
                    <div class="menu-tab">
                        <i class="fa-solid fa-folder"></i>
                        Documents
                    </div>
                     
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseDocuments" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a href="../secretary/index.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="templates-tab">
                                <i class="fa-regular fa-circle"></i>
                                Templates
                            </div>
                        </a>
                        <a href="../secretary/documents-today.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="documents-today-tab">
                                <i class="fa-regular fa-circle"></i>
                                Documents Today
                            </div>
                        </a>
                        <a href="../secretary/all-documents.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="all-documents-tab">
                                <i class="fa-regular fa-circle"></i>
                                All Documents
                            </div>
                        </a>
                        <a href="document-pricing.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="document-pricing-tab">
                                <i class="fa-regular fa-circle"></i>
                                Document Pricing
                            </div>
                        </a>
                    </nav>
                </div>

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseBilling" aria-expanded="true" aria-controls="collapseBilling">
                    <div class="menu-tab">
                        <i class="fa-solid fa-file-invoice"></i>
                        Billing
                    </div>

                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseBilling" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a href="../cashier/index.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="unpaid-doc-tab">
                                <i class="fa-regular fa-circle"></i>
                                Unpaid Documents
                            </div>
                        </a>

                        <a href="../cashier/paid-documents-today.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="paid-doc-tab">
                                <i class="fa-regular fa-circle"></i>
                                 Paid Today
                            </div>
                        </a>
                    </nav>
                </div>


                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseReports" aria-expanded="true" aria-controls="collapseReports">
                    <div class="menu-tab">
                        <i class="fa-regular fa-chart-bar"></i>
                        Reports
                    </div>

                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseReports" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a href="../secretary/reports.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="reports-tab">
                                <i class="fa-regular fa-circle"></i>
                                Doc Reports
                            </div>
                        </a>
                        <a href="../cashier/reports.php" style="text-decoration:none">
                            <div class="p-3 w-100 menu-tab" id="income-reports-tab">
                                <i class="fa-regular fa-circle"></i>
                                Income Reports
                            </div>
                        </a>
                    </nav>
                </div>

                <a href="user-list.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="user-list-tab">
                        <i class="fa-solid fa-users"></i>
                        User List
                    </div>
                </a>

                <a href="backup.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="backup-tab">
                        <i class="fas fa-database"></i>
                        Backup
                    </div>
                </a>

                <a href="account-settings.php" style="text-decoration:none">
                    <div class="p-3 w-100 menu-tab" id="account-settings-tab">
                        <i class="fa-solid fa-gear"></i>
                        Account Settings
                    </div>
                </a>


                <!-- <a class="nav-link templates-tab menu-tab" href="index.php">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-file-lines templates-tab menu-tab"></i></div>
                    Templates
                </a>

                <a class="nav-link documents-today-tab menu-tab" href="documents-today.php">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-file-lines documents-today-tab menu-tab"></i></div>
                    Documents Today
                </a>

                <a class="nav-link all-documents-tab menu-tab" href="all-documents.php">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-file-lines all-documents-tab menu-tab"></i></div>
                    All Documents
                </a> -->

            </div>
        </div>
    </nav>
</div>
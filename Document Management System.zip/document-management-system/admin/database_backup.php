<?php

    error_reporting(0);

	include 'backup_function.php';

	if(isset($_POST['backupnow'])){
		
		$server = $_POST['server'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$dbname = $_POST['dbname'];

		if($server == "localhost" && $username == "root" && $password == "" && $dbname == "dms"){
			backDb($server, $username, $password, $dbname);
			exit();
		}
		else{
			session_start();
			$prevLocation = $_SERVER["HTTP_REFERER"];
            $_SESSION['processing-message-alert'] = array("Your input is incorrect!","alert-danger");
            header("Location:$prevLocation");
		}

	}
	else{
		header("Location:index.php");
	}

?>
<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Admin | DMS</title>
        <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/all.min.css">
        <link rel="stylesheet" href="css/backup.css">
        <script src="js/jquery.min.js"></script>

   </head>
    <body class="sb-nav-fixed">

        <?php require_once('top-bar.php'); ?>

        <div id="layoutSidenav">

            <!-- Navigation Bar -->
            <?php require_once('navbar.php'); ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 mb-5">
                        <h1 class="mt-4">Backup</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home</li>
                            <li class="breadcrumb-item active">Backup</li>
                        </ol>

                        <!-- Alert -->
                        <div id="processing-message-alert" class="alert d-none text-center" role="alert"></div>

                        <div class="row">
                            <div class="form-wrap bg-light px-5 py-2" style="width:60%;margin:auto">
								<form action="database_backup.php" method="post" id="">
									<div class="form-group mt-3">
										<label class="control-label mb-10" >Host</label>
										<input type="text" class="form-control" placeholder="Enter Server Name EX: Localhost" name="server" id="server" required="" autocomplete="on" value="localhost">
									</div>
									<div class="form-group mt-3">
										<label class="control-label mb-10" >Database Username</label>
										<input type="text" class="form-control" placeholder="Enter Database Username EX: root" name="username" id="username" required="" autocomplete="on" value="root">
									</div>
									<div class="form-group mt-3">
										<label class="pull-left control-label mb-10" >Database Password</label>
										<input type="password" class="form-control" placeholder="" name="password" id="password" value="">
									</div>
									<div class="form-group mt-3">
										<label class="pull-left control-label mb-10">Database Name</label>
										<input type="text" class="form-control" placeholder="Enter Database Name" name="dbname" id="dbname" required="" autocomplete="on" value="dms">
									</div>
									<div class="form-group my-3 text-center">
										<button type="submit" name="backupnow" class="btn btn-danger btn-rounded">Initiate Backup</button>
									</div>
								</form>
							</div>
                        </div>



                    </div>
                </main>
            </div>
        </div>

        <!-- Javascript -->
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/backup.js"></script>
    </body>
</html>

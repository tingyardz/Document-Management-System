<?php
    require_once('../connection.php');

    //permision to view the page
    session_start();
    if($_SESSION['dms-login-User_Type'] !== "Admin"){
        header("Location:../index.php");
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Admin | DMS</title>
        <link rel="shortcut icon" href="../img/Logo.ico" type="image/x-icon">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/all.min.css">
        <link rel="stylesheet" href="css/index.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/chart.min.js"></script>

   </head>
    <body class="sb-nav-fixed">

        <?php require_once('top-bar.php'); ?>

        <div id="layoutSidenav">

            <!-- Navigation Bar -->
            <?php require_once('navbar.php'); ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 mb-5">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home</li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>

                        <div class="row">
                                <div class="col-xl-3 col-md-6">
                                    <div class="card text-white mb-4" style="background:rgb(86,86,224);;">
                                        <div id="overall-documents" class="card-body text-center" style="font-size:28pt;">0</div>
                                        <div class="card-footer d-flex align-items-center justify-content-between">
                                            <div class="text-center w-100"><a data-bs-toggle="modal" data-bs-target="#show-documents-number" href="#" class="text-light" id="over-all-documents">Overall Documents</a></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xl-3 col-md-6">
                                    <div class="card text-white mb-4" style="background: rgb(7,158,37);">
                                        <div id="total-documents-today" class="card-body text-center" style="font-size:28pt;">0</div>
                                        <div class="card-footer d-flex align-items-center justify-content-between">
                                        <div class="text-center w-100"><a data-bs-toggle="modal" data-bs-target="#show-documents-number-02" href="#" class="text-light" id="total-documents-today-02">Total Documents Today</a></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xl-3 col-md-6">
                                    <div class="card text-white mb-4" style="background: rgb(222,38,76);">
                                        <div id="total-income-today" class="card-body text-center" style="font-size:28pt;">0</div>
                                        <div class="card-footer d-flex align-items-center justify-content-between">
                                            <div class="text-center w-100">Total Income Today</div>
                                        </div>
                                    </div>
                                </div>


                                <div class="mb-4" style="width:80%;margin:auto">
                                    <div class="bg-light py-3 px-3">
                                        <div style="height:40px;position:relative;">
                                            <select class="form-select w-25 selector_1-chart" name="" id="selector_1-chart" style="position:absolute;right:10px;">

                                            </select>
                                        </div>
                                        <center>
                                            <div class="col" id="chart_1">
                                                <canvas id="number-of-documents-created-chart"></canvas>
                                            </div>
                                        </center>
                                    </div>
                                </div>


                                <div class="mb-4" style="width:80%;margin:auto">
                                    <div class="bg-light py-3 px-3">
                                        <div style="height:40px;position:relative;">
                                            <select class="form-select w-25 selector_1-chart" name="" id="selector_2-chart" style="position:absolute;right:10px;">

                                            </select>
                                        </div>
                                        <center>
                                            <div class="col" id="chart_2">
                                                <canvas id="total-income-chart"></canvas>
                                            </div>
                                        </center>
                                    </div>
                                </div>

                        </div>

                    </div>
                </main>
            </div>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="show-documents-number" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog" style="max-width:60%;">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Overall Documents</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body pb-4">
                <div style="height:460px;overflow:auto;border:solid 1px rgb(210,210,210);">
                    <table id="table-01" class="table">
                        <thead class="" id="thead-01" style="position:sticky;top:0;background-color:white;">
                            <tr>
                                <th>Document Title</th>
                                <th>No. of Documents</th>
                            </tr>
                        </thead>
                        <tbody id="tbody-01">
                            
                        </tbody>
                    </table>
                </div>
              </div>
            </div>
          </div>
        </div>


        <div class="modal fade" id="show-documents-number-02" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog" style="max-width:60%;">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Documents Today</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body pb-4">
                <div style="height:460px;overflow:auto;border:solid 1px rgb(210,210,210);">
                    <table id="table-02" class="table">
                        <thead class="" id="thead-02" style="position:sticky;top:0;background-color:white;">
                            <tr>
                                <th>Document Title</th>
                                <th>No. of Documents</th>
                            </tr>
                        </thead>
                        <tbody id="tbody-02">

                        </tbody>
                    </table>
                </div>
              </div>
            </div>
          </div>
        </div>


        <!-- Javascript -->
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/dashboard.js"></script>
        <script src="js/chart-documents.js"></script>
        <script src="js/chart-income.js"></script>
    </body>
</html>

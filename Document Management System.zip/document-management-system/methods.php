<?php
    class Methods{

        var $connect;

        public function __construct(){
            require('connection.php');
            $this->connect = $connect;
        }

        function getTemplateStatus(){
            $temp_id = $_POST['temp_id'];
            $sql = "SELECT * FROM `price_tbl` WHERE `Temp_Id` = '$temp_id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $total = $query->num_rows;
            if($total){
                return 1;
            }
            else{
                return 0;
            }
        }

        function getOverallDocuments(){
            $sql = "SELECT *, `Id` AS `title_id` FROM `documents_title_tbl`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $td = "";
            $count = 0;
            while ($row = $query->fetch_assoc()) {
                $title = $row['Title'];
                $titleId = $row['title_id'];
                $sql01 = "SELECT * FROM `documents_tbl` WHERE `Title_Id` = '$titleId'";
                $query01 = $this->connect->query($sql01) or die($this->connect->error);
                $total01 = $query01->num_rows;
                if($total01){
                    $count++;
                    $td = $td."<tr><td>$title</td>"."<td>$total01</td><tr>";
                }
            }
            
            if($count){
                return $td;
            }
            else{
                return '<tr> <td class="text-center" colspan="2">No Documents Yet!</td> </tr>';
            }
        }

        function getTotalDocumentsToday(){
            session_start();
            $dateToday = $_SESSION['date-today'];
            $sql = "SELECT *, `Id` AS `title_id` FROM `documents_title_tbl`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $td = "";
            $count = 0;
            while ($row = $query->fetch_assoc()) {
                $title = $row['Title'];
                $titleId = $row['title_id'];
                $sql01 = "SELECT * FROM `documents_tbl`
                          INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id` WHERE `documents_tbl`.`Title_Id` = '$titleId' AND `client_data_tbl`.`Date_Added` = '$dateToday' ";
                $query01 = $this->connect->query($sql01) or die($this->connect->error);
                $total01 = $query01->num_rows;
                if($total01){
                    $count++;
                    $td = $td."<tr><td>$title</td>"."<td>$total01</td></tr>";
                }
            }
            
            if($count){
                return $td;
            }
            else{
                return '<tr> <td class="text-center" colspan="2">No Documents Yet!</td> </tr>';
            }
        }


        function getDefaultName(){
            $id = $_POST['id'];
            $sql = "SELECT `Client_Name` FROM `documents_tbl` WHERE `documents_tbl`.`Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            return $row['Client_Name'];
        }

        function getTemplatesData01(){
            $tempId = $_POST['tempId'];
            $sql = "SELECT * FROM `doc_templates_tbl` INNER JOIN `documents_title_tbl` ON `doc_templates_tbl`.`Title_Id` = `documents_title_tbl`.`Id` WHERE `doc_templates_tbl`.`Id` = '$tempId'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $result = array($tempId, $row['Title_Id'], $row['Title']);
            return json_encode($result);
        }

        function getClientDocket(){
            $id = $_POST['clientId'];
            $sql = "SELECT * FROM `client_data_tbl` WHERE `ClientData_Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $docket = array($row['Doc_No'],$row['Page_No'],$row['Book_No'],$row['Series_of']);
            return json_encode($docket);
        }

        function removeClientData(){
            $id = $_POST['id'];
            $sql = "DELETE FROM `documents_tbl` WHERE `Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            return "SUCCESS";
        }

        function searchingForReports(){
            $searchValue = $_POST['searchValue'];
            $category = $_POST['category'];
            switch ($category) {
                case 'title':
                    $sql = "SELECT * FROM `documents_title_tbl` WHERE `Title` LIKE '$searchValue%'";
                    $query = $this->connect->query($sql) or die($this->connect->error);
                    $output = "";
                    if($query->num_rows){
                        while ($row = $query->fetch_assoc()) {
                            $title = $row['Title'];
                            $output = $output."<li onclick='selectedInput(\"$title\")'>$title</li>";
                        }
                        return $output;
                    }
                    else{
                        $output = $output."<li>No such data found!</li>";
                        return $output;
                    }
                    break;
                
                case 'client-name':
                    $sql = "SELECT * FROM `client_nameList_tbl` WHERE `Full_Name` LIKE '$searchValue%'";
                    $query = $this->connect->query($sql) or die($this->connect->error);
                    $output = "";
                    if($query->num_rows){
                        while ($row = $query->fetch_assoc()) {
                            $clientName = $row['Full_Name'];
                            $output = $output."<li onclick='selectedInput(\"$clientName\")'>$clientName</li>";
                        }
                        return $output;
                    }
                    else{
                        $output = $output."<li>No such data found!</li>";
                        return $output;
                    }
                    break;
            }
        }

        function getClientData(){
            $id = $_POST['docId'];
            $sql = "SELECT `First_Name`, `Middle_Name`, `Last_Name`, `Age`, `Citizenship`, `Legal_Status`, `Address`, `Valid_Id`, `Id_Exp`, `Doc_No`, `Page_No`, `Book_No`, `Series_of`, `Client_Data` FROM `documents_tbl`
                    INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id`  WHERE `documents_tbl`.`Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $output = array();
            foreach ($row as $key => $value) {
                array_push($output, $value);
            }
            return json_encode($output);
        }

        function getTemplatesData(){
            $temp_id = $_POST['temp_id'];
            $sql = "SELECT * FROM `doc_templates_tbl` WHERE `Id` = '$temp_id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $id = $row['Id'];
            $header = $row['Header'];
            $body = $row['Body'];
            $footer = $row['Footer'];
            $output = array($id, $header, $body, $footer);
            return json_encode($output);
        }

        function getTemplatesFrom(){
            $titleId = $_POST['titleId'];
            $sql = "SELECT `Template_Form` FROM `doctemplatesstructure_tbl` WHERE `Title_Id` = '$titleId'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            if($query->num_rows > 0){
                $output = array($titleId, $row['Template_Form']);
                return json_encode($output);
            }
            else{
                return "ERROR";
            }
        }

        function searchForDocTitle(){
            $search = $_POST['search'];
            $sql = "SELECT * FROM `documents_title_tbl` WHERE `Title` LIKE '$search%'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $total = $query->num_rows;
            $output = "";
            if($total){
                while ($row = $query->fetch_assoc()) {
                    $title = $row['Title'];
                    $doc_id = $row['Id'];
                    $output = $output."<p class='m-0 p-2 search-result' onclick='chosenTitle(\"$title\",$doc_id)'><i class='fa-solid fa-magnifying-glass mx-3'></i>$title</p>";
                }
                return $output;
            }
            else{
                return "<p class='m-0 p-2 text-center'>Please check your keyword!</p>";
            }
        }

        function getTheNumberOfPaidDocuments(){
            $sql = "SELECT * FROM `documents_tbl` WHERE `Status` = 'PAID'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $total = $query->num_rows;
            return $total;
        }

        function getTheTop5MostRequestedDocuments(){
            //get all documents title
            $allDocumentsTitle = array();
            $sql = "SELECT * FROM `templates_tbl`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            while ($row = $query->fetch_assoc()) {
                array_push($allDocumentsTitle,$row['Title']);
            }

            $totalOfEachDocuments = array();
            for ($i=0; $i < count($allDocumentsTitle); $i++) { 
                $documentTitle = $allDocumentsTitle[$i];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Status` = 'PAID' AND `Title` = '$documentTitle'";
                $query = $this->connect->query($sql) or die($this->connect->error);
                array_push($totalOfEachDocuments,$query->num_rows);
            }

            $topFiveScores = array();
            $counter = 0;
            for ($i=0; $i < 5; $i++) { 
                for ($j=0; $j < count($totalOfEachDocuments); $j++) { 
                    for ($y=0; $y < count($totalOfEachDocuments); $y++) { 
                        if($totalOfEachDocuments[$j] >= $totalOfEachDocuments[$y]){
                            $counter++;
                            if($counter == count($totalOfEachDocuments)){
                                array_push($topFiveScores,[$allDocumentsTitle[$j],$totalOfEachDocuments[$j]]);
                                break;
                             }
                        }
                    }
                    if($counter == count($totalOfEachDocuments)){
                        $totalOfEachDocuments[$j] = 0;
                        break;
                    }
                    else{
                        $counter = 0;
                    }
                }
                $counter = 0;
            }

            return json_encode($topFiveScores);

        }

        function getOverallIncome(){
            $sql = "SELECT * FROM `payment_tbl`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $output = 0;
            while ($row = $query->fetch_assoc()) {
                $output = $output + $row['Final_Amount'];
            }
            return $output;
        }

        function getTotalIncomePerMonth(){
            $selectedYear = $_POST['selectedYear'];
            $sql = "SELECT * FROM `payment_tbl`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $output = array(0,0,0,0,0,0,0,0,0,0,0,0);
            $nextYear = $selectedYear + 1;
            while ($row = $query->fetch_assoc()) {
                $date = $row['Date'];
                if("$selectedYear-01-01" <= $date && $date < "$selectedYear-02-01"){
                    $output[0] = $output[0] + $row['Final_Amount'];
                }
                elseif("$selectedYear-02-01" <= $date && $date < "$selectedYear-03-01"){
                    $output[1] = $output[1] + $row['Final_Amount'];
                }
                elseif("$selectedYear-03-01" <= $date && $date < "$selectedYear-04-01"){
                    $output[2] = $output[2] + $row['Final_Amount'];
                }
                elseif("$selectedYear-04-01" <= $date && $date < "$selectedYear-05-01"){
                    $output[3] = $output[3] + $row['Final_Amount'];
                }
                elseif("$selectedYear-05-01" <= $date && $date < "$selectedYear-06-01"){
                    $output[4] = $output[4] + $row['Final_Amount'];
                }
                elseif("$selectedYear-06-01" <= $date && $date < "$selectedYear-07-01"){
                    $output[5] = $output[5] + $row['Final_Amount'];
                }
                elseif("$selectedYear-07-01" <= $date && $date < "$selectedYear-08-01"){
                    $output[6] = $output[6] + $row['Final_Amount'];
                }
                elseif("$selectedYear-08-01" <= $date && $date < "$selectedYear-09-01"){
                    $output[7] = $output[7] + $row['Final_Amount'];
                }
                elseif("$selectedYear-09-01" <= $date && $date < "$selectedYear-10-01"){
                    $output[8] = $output[8] + $row['Final_Amount'];
                }
                elseif("$selectedYear-10-01" <= $date && $date < "$selectedYear-11-01"){
                    $output[9] = $output[9] + $row['Final_Amount'];
                }
                elseif("$selectedYear-11-01" <= $date && $date < "$selectedYear-12-01"){
                    $output[10] = $output[10] + $row['Final_Amount'];
                }
                elseif("$selectedYear-12-01" <= $date && $date < "$nextYear-01-01"){
                    $output[11] = $output[11] + $row['Final_Amount'];
                }
            }
            return json_encode($output);
        }

        function getTotalDocumentsThisYear(){
            $selectedYear = $_POST['selectedYear'];
            $sql = "SELECT * FROM `documents_tbl` 
                    INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $output = array(0,0,0,0,0,0,0,0,0,0,0,0);
            $nextYear = $selectedYear + 1;
            while ($row = $query->fetch_assoc()) {
                $date = $row['Date_Added'];
                if("$selectedYear-01-01" <= $date && $date < "$selectedYear-02-01"){
                    $output[0] = $output[0] + 1;
                }
                elseif("$selectedYear-02-01" <= $date && $date < "$selectedYear-03-01"){
                    $output[1] = $output[1] + 1;
                }
                elseif("$selectedYear-03-01" <= $date && $date < "$selectedYear-04-01"){
                    $output[2] = $output[2] + 1;
                }
                elseif("$selectedYear-04-01" <= $date && $date < "$selectedYear-05-01"){
                    $output[3] = $output[3] + 1;
                }
                elseif("$selectedYear-05-01" <= $date && $date < "$selectedYear-06-01"){
                    $output[4] = $output[4] + 1;
                }
                elseif("$selectedYear-06-01" <= $date && $date < "$selectedYear-07-01"){
                    $output[5] = $output[5] + 1;
                }
                elseif("$selectedYear-07-01" <= $date && $date < "$selectedYear-08-01"){
                    $output[6] = $output[6] + 1;
                }
                elseif("$selectedYear-08-01" <= $date && $date < "$selectedYear-09-01"){
                    $output[7] = $output[7] + 1;
                }
                elseif("$selectedYear-09-01" <= $date && $date < "$selectedYear-10-01"){
                    $output[8] = $output[8] + 1;
                }
                elseif("$selectedYear-10-01" <= $date && $date < "$selectedYear-11-01"){
                    $output[9] = $output[9] + 1;
                }
                elseif("$selectedYear-11-01" <= $date && $date < "$selectedYear-12-01"){
                    $output[10] = $output[10] + 1;
                }
                elseif("$selectedYear-12-01" <= $date && $date < "$nextYear-01-01"){
                    $output[11] = $output[11] + 1;
                }
            }
            return json_encode($output);
        }

        function getAllPassingYears(){
            $currentYear = $_POST['currentYear'];
            $sql = "SELECT * FROM `year_tbl` WHERE `Year` = '$currentYear'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $total = $query->num_rows;

            if($total == 0){
                $sql = "INSERT INTO `year_tbl`(`Year`) VALUES ('$currentYear')";
                $query = $this->connect->query($sql) or die($this->connect->error);
            }
            
            $sql = "SELECT * FROM `year_tbl`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $output = array();
            while ($row = $query->fetch_assoc()) {
                array_push($output,$row['Year']);
            }
            return json_encode($output);
        }

        function getAllStats(){
            //get the total documents
            $sql = "SELECT * FROM `documents_tbl`";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $totalDocuments = $query->num_rows;

            //get the total documents today
            session_start();
            $dateToday = $_SESSION['date-today'];
            $sql_1 = "SELECT * FROM `documents_tbl`
                      INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id` WHERE `client_data_tbl`.`Date_Added` = '$dateToday'";
            $query_1 = $this->connect->query($sql_1) or die($this->connect->error);
            $totalDocumentsToday = $query_1->num_rows;

            //get the total income today
            $sql_2 = "SELECT * FROM `payment_tbl` WHERE `Date` = '$dateToday'";
            $query_2 = $this->connect->query($sql_2) or die($this->connect->error);
            $totalIncomeToday = 0;
            while ($row_2 = $query_2->fetch_assoc()) {
                $totalIncomeToday = $totalIncomeToday + $row_2['Final_Amount'];
            }

            $output = array("totalDocuments" => $totalDocuments,"totalDocumentsToday" => $totalDocumentsToday,"totalIncomeToday" => $totalIncomeToday);
            return json_encode($output);

        }

        function getProcessMessageAlert(){
            session_start();
            if(isset($_SESSION['processing-message-alert'])){
                $data = $_SESSION['processing-message-alert'];
                unset($_SESSION['processing-message-alert']);
                return json_encode($data);
            }
        }

        function getSubDocData(){
            $id = $_POST['id'];
            $sql = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            return $row['SubDocument_Name'];
        }

        function getNumberOfDataFromDocumentsTable(){
            if(isset($_POST['searchData'])){
                $searchFor = $_POST['value'];
                session_start();
                $sql = "SELECT * FROM `documents_tbl` WHERE `Title` LIKE '%$searchFor%' || `Client_Name` LIKE '%$searchFor%' ";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $total = $query->num_rows;
                return $total;
            }
            else{
                session_start();
                $sql = "SELECT * FROM `documents_tbl`";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $total = $query->num_rows;
                return $total;
            }
        }

        function getAllDataFromDocumentsTable(){
            if(isset($_POST['searchDataPreviousPage'])){
                $searchFor = $_POST['value'];
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $sql = "SELECT * FROM `documents_tbl` WHERE `Title` LIKE '%$searchFor%' || `Client_Name` LIKE '%$searchFor%' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            elseif(isset($_POST['searchDataNextPage'])){
                $searchFor = $_POST['value'];
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $sql = "SELECT * FROM `documents_tbl` WHERE `Title` LIKE '%$searchFor%' || `Client_Name` LIKE '%$searchFor%' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            elseif(isset($_POST['searchData'])){
                $searchFor = $_POST['value'];
                session_start();
                $sql = "SELECT * FROM `documents_tbl` WHERE `Title` LIKE '%$searchFor%' || `Client_Name` LIKE '%$searchFor%' LIMIT 5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                if($query->num_rows == 0){
                    $output = "<tr><td class=\"text-center\" colspan=\"7\">No data found.</td></tr>";
                }
                return $output;
            }
            elseif(isset($_POST['nextPage'])){
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $sql = "SELECT * FROM `documents_tbl` LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            elseif(isset($_POST['previousPage'])){
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $sql = "SELECT * FROM `documents_tbl` LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            else{
                session_start();
                $sql = "SELECT * FROM `documents_tbl` LIMIT 5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                if($query->num_rows == 0){
                    $output = "<tr><td class=\"text-center\" colspan=\"7\">No data found.</td></tr>";
                }
                return $output;
            }
        }

        function getNumberOfDataFromDocumentsTableForToday(){
            if(isset($_POST['searchData'])){
                $searchFor = $_POST['value'];
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday' AND `Title` LIKE '%$searchFor%' || `Date` = '$dateToday' AND `Client_Name` LIKE '%$searchFor%' ";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $total = $query->num_rows;
                return $total;
            }
            else{
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday'";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $total = $query->num_rows;
                return $total;
            }
        }

        function getDataFromDocumentsTableForToday(){
            if(isset($_POST['searchDataPreviousPage'])){
                $searchFor = $_POST['value'];
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday' AND `Title` LIKE '%$searchFor%' || `Date` = '$dateToday' AND `Client_Name` LIKE '%$searchFor%' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            elseif(isset($_POST['searchDataNextPage'])){
                $searchFor = $_POST['value'];
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday' AND `Title` LIKE '%$searchFor%' || `Date` = '$dateToday' AND `Client_Name` LIKE '%$searchFor%' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            elseif(isset($_POST['searchData'])){
                $searchFor = $_POST['value'];
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday' AND `Title` LIKE '%$searchFor%' || `Date` = '$dateToday' AND `Client_Name` LIKE '%$searchFor%' LIMIT 5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                if($query->num_rows == 0){
                    $output = "<tr><td class=\"text-center\" colspan=\"7\">No data found.</td></tr>";
                }
                return $output;
            }
            elseif(isset($_POST['nextPage'])){
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            elseif(isset($_POST['previousPage'])){
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                return $output;
            }
            else{
                session_start();
                $dateToday = $_SESSION['date-today'];
                $sql = "SELECT * FROM `documents_tbl` WHERE `Date` = '$dateToday' LIMIT 5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $docNo = $row['Doc_No'];
                    $date = $row['Date'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $id = $row['Id'];
                    $status = $row['Status'];

                    switch ($status) {
                        case 'PAID':
                            $statusColor = 'text-success';
                            break;
                        
                        case 'UNPAID':
                            $statusColor = 'text-danger';
                            break;
                    }

                    //check subdocuments
                    $sql01 = "SELECT * FROM `subdocuments_tbl` WHERE `Doc_Id` = '$id'";
                    $query01 = $this->connect->query($sql01) or die($this->connect->error);
                    $row01 = $query01->fetch_assoc();
                    $total01 = $query01->num_rows;
                    if($total01){
                        $subDocumentsSection = "
                        <i onclick=\"updateSubDoc($id)\" class=\"fa-solid fa-file-pen text-primary icon-000\" title=\"Update Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#updateSubDoc\"></i>
                        <a href=\"download.php?subDocId=$id\"><i class=\"fa-solid fa-file-lines text-success icon-000\" title=\"Subdocument\"></i><a/>
                        <i onclick=\"removeSubDoc($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Subdocument\"></i>
                        ";
                    }
                    else{
                        $subDocumentsSection = "<i onclick=\"addSubDoc($id)\" class=\"fa-solid fa-file-circle-plus text-primary icon-000\" title=\"Add Subdocument\" data-bs-toggle=\"modal\" data-bs-target=\"#addSubDoc\"></i>";
                    }

                    $output = $output."
                        <tr>
                            <td>$docNo</td>
                            <td>$date</td>
                            <td>$title</td>
                            <td>$clientName</td>
                            <td>$secretaryName</td>
                            <td class=\"$statusColor\">$status</td>
                            <td>
                                <div class=\"d-none action-subdoc-$id\">
                                    <i onclick=\"showActionIcons($id)\" class=\"fa-solid fa-chevron-left text-warning icon-000\" title=\"Previous\"></i>
                                    $subDocumentsSection   
                                </div>

                                <div class=\"action-icons-$id\">
                                    <i onclick=\"openNewWindow('view.php?doc=$id')\" class=\"fa-solid fa-eye text-primary icon-000\" title=\"View Document\"></i>
                                    <i onclick=\"getDocumentData($id)\" id=\"update-document-icon\" class=\"fa-solid fa-pen-to-square text-info icon-000\" title=\"Update Document\" data-bs-toggle=\"modal\" data-bs-target=\"#update-document-modal\"></i>
                                    <i onclick=\"removeDocument($id)\" class=\"fa-solid fa-trash text-danger icon-000\" title=\"Remove Document\"></i>
                                    <i onclick=\"hideActionIcons($id)\" class=\"fa-solid fa-chevron-right text-warning icon-000\" title=\"Next\"></i>
                                </div>
                            </td>
                        </tr>
                    ";
                }
                if($query->num_rows == 0){
                    $output = "<tr><td class=\"text-center\" colspan=\"7\">No data found.</td></tr>";
                }
                return $output;
            }
        }

        function getTheNumberOfDisabledTemplates(){
            $sql = "SELECT * FROM `templates_tbl` WHERE `Status` = 'Disable'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            return $query->num_rows;
        }

        function getNumberOfDataFromTemplatesTable(){
            if(isset($_POST['searchData'])){
                $searchFor = $_POST['value'];
                $sql = "SELECT * FROM `templates_tbl` WHERE `Title` LIKE '%$searchFor%' ";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $total = $query->num_rows;
                return $total;
            }
            else{
                $sql = "SELECT * FROM `templates_tbl`";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $total = $query->num_rows;
                return $total;
            }
        }

        function getDataFromTemplatesTable(){
            if(isset($_POST['searchDataPreviousPage'])){
                $searchFor = $_POST['value'];
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                $sql = "SELECT * FROM `templates_tbl` WHERE `Title` LIKE '%$searchFor%' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $id = $row['Id'];
                    $title = $row['Title'];
                    if($row['Status'] === "Enable"){
                        $createDocument = "openNewWindow('create-document.php?temp_id=".$id."')";
                    }else{
                        $createDocument = "createDocumentDisabled()";
                    }
                    $output = $output."
                                        <tr>
                                            <td>$id</td>
                                            <td>$title</td>
                                            <td>
                                                <i onclick=\"$createDocument\" title=\"Create Document\" class=\"fa-solid fa-file-export icon-000 text-primary\"></i>
                                                <i onclick=\"openNewWindow('update-template.php?temp_id=$id')\" title=\"Update Template\" id=\"update-template-icon\" class=\"fa-solid fa-pen-to-square icon-000 text-info\"></i>
                                                <i onclick=\"removeTemplate($id)\" title=\"Remove Template\" class=\"fa-solid fa-trash icon-000 text-danger\"></i>
                                            </td>
                                        </tr>";
                }
                return $output;
            }
            elseif(isset($_POST['searchDataNextPage'])){
                $searchFor = $_POST['value'];
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                $sql = "SELECT * FROM `templates_tbl` WHERE `Title` LIKE '%$searchFor%' LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $id = $row['Id'];
                    $title = $row['Title'];
                    if($row['Status'] === "Enable"){
                        $createDocument = "openNewWindow('create-document.php?temp_id=".$id."')";
                    }else{
                        $createDocument = "createDocumentDisabled()";
                    }
                    $output = $output."
                                        <tr>
                                            <td>$id</td>
                                            <td>$title</td>
                                            <td>
                                                <i onclick=\"$createDocument\" title=\"Create Document\" class=\"fa-solid fa-file-export icon-000 text-primary\"></i>
                                                <i onclick=\"openNewWindow('update-template.php?temp_id=$id')\" title=\"Update Template\" id=\"update-template-icon\" class=\"fa-solid fa-pen-to-square icon-000 text-info\"></i>
                                                <i onclick=\"removeTemplate($id)\" title=\"Remove Template\" class=\"fa-solid fa-trash icon-000 text-danger\"></i>
                                            </td>
                                        </tr>";
                }
                return $output;
            }
            elseif(isset($_POST['searchData'])){
                $searchFor = $_POST['value'];
                $sql = "SELECT * FROM `templates_tbl` WHERE `Title` LIKE '%$searchFor%' LIMIT 5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $id = $row['Id'];
                    $title = $row['Title'];
                    if($row['Status'] === "Enable"){
                        $createDocument = "openNewWindow('create-document.php?temp_id=".$id."')";
                    }else{
                        $createDocument = "createDocumentDisabled()";
                    }
                    $output = $output."
                                        <tr>
                                            <td>$id</td>
                                            <td>$title</td>
                                            <td>
                                                <i onclick=\"$createDocument\" title=\"Create Document\" class=\"fa-solid fa-file-export icon-000 text-primary\"></i>
                                                <i onclick=\"openNewWindow('update-template.php?temp_id=$id')\" title=\"Update Template\" id=\"update-template-icon\" class=\"fa-solid fa-pen-to-square icon-000 text-info\"></i>
                                                <i onclick=\"removeTemplate($id)\" title=\"Remove Template\" class=\"fa-solid fa-trash icon-000 text-danger\"></i>
                                            </td>
                                        </tr>";
                }
                if($query->num_rows == 0){
                    $output = "<tr><td class=\"text-center\" colspan=\"7\">No data found.</td></tr>";
                }
                return $output;
            }
            elseif(isset($_POST['nextPage'])){
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                $sql = "SELECT * FROM `templates_tbl` LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $id = $row['Id'];
                    $title = $row['Title'];
                    if($row['Status'] === "Enable"){
                        $createDocument = "openNewWindow('create-document.php?temp_id=".$id."')";
                    }else{
                        $createDocument = "createDocumentDisabled()";
                    }
                    $output = $output."
                                        <tr>
                                            <td>$id</td>
                                            <td>$title</td>
                                            <td>
                                                <i onclick=\"$createDocument\" title=\"Create Document\" class=\"fa-solid fa-file-export icon-000 text-primary\"></i>
                                                <i onclick=\"openNewWindow('update-template.php?temp_id=$id')\" title=\"Update Template\" id=\"update-template-icon\" class=\"fa-solid fa-pen-to-square icon-000 text-info\"></i>
                                                <i onclick=\"removeTemplate($id)\" title=\"Remove Template\" class=\"fa-solid fa-trash icon-000 text-danger\"></i>
                                            </td>
                                        </tr>";
                }
                return $output;
            }
            elseif(isset($_POST['previousPage'])){
                $starFrom = ($_POST['currentPage'] * 5) - 5;
                $sql = "SELECT * FROM `templates_tbl` LIMIT $starFrom,5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $id = $row['Id'];
                    $title = $row['Title'];
                    if($row['Status'] === "Enable"){
                        $createDocument = "openNewWindow('create-document.php?temp_id=".$id."')";
                    }else{
                        $createDocument = "createDocumentDisabled()";
                    }
                    $output = $output."
                                        <tr>
                                            <td>$id</td>
                                            <td>$title</td>
                                            <td>
                                                <i onclick=\"$createDocument\" title=\"Create Document\" class=\"fa-solid fa-file-export icon-000 text-primary\"></i>
                                                <i onclick=\"openNewWindow('update-template.php?temp_id=$id')\" title=\"Update Template\" id=\"update-template-icon\" class=\"fa-solid fa-pen-to-square icon-000 text-info\"></i>
                                                <i onclick=\"removeTemplate($id)\" title=\"Remove Template\" class=\"fa-solid fa-trash icon-000 text-danger\"></i>
                                            </td>
                                        </tr>";
                }
                return $output;
            }
            else{
                $sql = "SELECT * FROM `templates_tbl` LIMIT 5";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $output = "";
                while ($row = $query->fetch_assoc()) {
                    $id = $row['Id'];
                    $title = $row['Title'];
                    if($row['Status'] === "Enable"){
                        $createDocument = "openNewWindow('create-document.php?temp_id=".$id."')";
                    }else{
                        $createDocument = "createDocumentDisabled()";
                    }
                    $output = $output."
                                        <tr>
                                            <td>$id</td>
                                            <td>$title</td>
                                            <td>
                                                <i onclick=\"$createDocument\" title=\"Create Document\" class=\"fa-solid fa-file-export icon-000 text-primary\"></i>
                                                <i onclick=\"openNewWindow('update-template.php?temp_id=$id')\" title=\"Update Template\" id=\"update-template-icon\" class=\"fa-solid fa-pen-to-square icon-000 text-info\"></i>
                                                <i onclick=\"removeTemplate($id)\" title=\"Remove Template\" class=\"fa-solid fa-trash icon-000 text-danger\"></i>
                                            </td>
                                        </tr>";
                }
                if($query->num_rows == 0){
                    $output = "<tr><td class=\"text-center\" colspan=\"7\">No data found.</td></tr>";
                }
                return $output;
            }
        }

        function getNewTemplateData(){
            $sql = "SELECT * FROM `templates_tbl` WHERE `Status` = 'Disable'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $output = "";

            while ($row = $query->fetch_assoc()) {
                $id = $row['Id'];
                $title = $row['Title'];
                $output = $output."
                                    <tr>
                                        <td>$id</td>
                                        <td>$title</td>
                                        <td><button onclick='getTemplatesData($id,\"$title\")' class='setPriceBtn' data-bs-toggle='modal' data-bs-target='#set-document-price-modal'>Set Price</button></td>
                                    </tr>

                                    ";
            }

            if($query->num_rows == 0){
                $output = $output."
                                    <tr>
                                        <td class='dataTables-empty' colspan='3'>No entries found</td>
                                    </tr>
                                    ";
            }

            return $output;
        }

        function getTheNumberOfTheNewTemplate(){
            $sql = "SELECT * FROM `templates_tbl` WHERE `Status` = 'Disable'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            return $query->num_rows;
        }

        function removeDataFromPriceTable(){
            try {
                $id = $_POST['dataId'];
                $sql = "SELECT * FROM `doc_templates_tbl` WHERE `Id` = '$id'";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $total = $query->num_rows;
                if($total == 0){
                    $sql = "DELETE FROM `price_tbl` WHERE `Temp_Id` = '$id'";
                    $query = $this->connect->query($sql) or die($this->connect->error);
                    return "Success";
                }
                else{
                    session_start();
                    $_SESSION['processing-message-alert'] = array("Due to the persistence of the template, you cannot erase this data!","alert-danger");
                    return "Restricted";
                }
            } catch (\Throwable $th) {
                return "Failed";
            }
        }

        function getDocumentPrice(){
            $id = $_POST['documentId'];
            $sql = "SELECT `Title`,`Price`,`price_tbl`.`Id` FROM `price_tbl`
                    INNER JOIN `documents_title_tbl` ON `documents_title_tbl`.`Id` = `price_tbl`.`Title_Id` WHERE `price_tbl`.`Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            return json_encode($row);
        }

        function removeUser(){
            $userId = $_POST['userId'];
            try {
                $sql = "DELETE FROM `user_tbl` WHERE `Id` = '$userId'";
                $query = $this->connect->query($sql) or die($this->connect->error);
                return "Success";
            } catch (\Throwable $th) {
                return "Failed";
            }
        }

        function getUserData(){
            $userId = $_POST['id'];
            $sql = "SELECT * FROM `user_tbl` WHERE `Id` = '$userId'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            return json_encode($row);
        }

        function getDataForMultipleDocuments(){
            $selectedData = $_POST['selectedData'];
            $totalAmount = 0;
            foreach ($selectedData as $key => $value) {
                $sql = "SELECT * FROM `documents_tbl`
                        INNER JOIN `price_tbl` ON `price_tbl`.`Temp_Id` = `documents_tbl`.`Temp_Id` WHERE `documents_tbl`.`Id`='$value'";
                $query = $this->connect->query($sql) or die($this->connect->error);
                $row = $query->fetch_assoc();
                $totalAmount = $totalAmount + $row['Price'];
            }
            session_start();
            $_SESSION['selected-data-for-payment'] = $selectedData;
            return $totalAmount;
        }

        function searchUnpaidDoc(){
            $search = $_POST['search'];
            $sql = "SELECT *, `documents_tbl`.`Id` AS `doc_id` FROM `documents_tbl`
                    INNER JOIN `client_data_tbl` ON `client_data_tbl`.`Id` = `documents_tbl`.`Client_Data_Id`
                    JOIN `documents_title_tbl` ON `documents_title_tbl`.`Id` = `documents_tbl`.`Title_Id`
                    JOIN `price_tbl` ON `price_tbl`.`Temp_Id` = `documents_tbl`.`Temp_Id` WHERE `Status`='0' AND `Client_Name` LIKE '%$search%' ORDER BY `Id` DESC";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $total = $query->num_rows;
            $output = "";
    
            if($total){
                do{
                    $id = $row['doc_id'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Produced_By'];
                    $date = $row['Date_Added'];
                    $status = "UNPAID";
                    $amount = $row['Price'];
    
                    $docNo = $row['Doc_No'];
                    $pageNo = $row['Page_No'];
                    $bookNo = $row['Book_No'];
                    $seriesOf = $row['Series_of'];
                    if(!empty($docNo) && !empty($pageNo) && !empty($bookNo) && !empty($seriesOf)){
                        $output = $output."
                            <tr>
                                <td><input onclick='checkbox()' class='checkbox' type='checkbox' value='$id'></td>
                                <td>$docNo</td>
                                <td>$title</td>
                                <td>$clientName</td>
                                <td>$secretaryName</td>
                                <td>$date</td>
                                <td class='text-danger'>$status</td>
                                <td><button onclick='setPayment($id,\"$title\",$amount,\"$clientName\")' class='bg-success text-light p-1' style='border:none;' data-bs-toggle='modal' data-bs-target='#single-payment-modal'>PayNow</button></td>
                            </tr>
                        ";
                    }
                }while($row = $query->fetch_assoc());
            
                return $output;
            }
            else{
                $output = $output."<tr><td class='dataTables-empty' colspan='8'>No entries found</td></tr>";
                return $output;
            }
        }

        function createBill(){
            session_start();
            $_SESSION['create-bill'] = $_POST['selectedData'];
            $_SESSION['billing-title'] = $_POST['billingTitle'];
            return "SUCCESS";
        }

        function getNewUnpaidDoc(){
            $sql = "SELECT * FROM `documents_tbl` WHERE `Status`='UNPAID' ORDER BY `Id` DESC";
            $query = $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $total = $query->num_rows;
            $output = "";

            if($total){
                do{
                    $id = $row['Id'];
                    $title = $row['Title'];
                    $clientName = $row['Client_Name'];
                    $secretaryName = $row['Secretary_Name'];
                    $date = $row['Date'];
                    $status = $row['Status'];
                    $amount = $row['Amount'];

                    $docNo = $row['Doc_No'];
                    $pageNo = $row['Page_No'];
                    $bookNo = $row['Book_No'];
                    $seriesOf = $row['Series_of'];
                    if(!empty($docNo) && !empty($pageNo) && !empty($bookNo) && !empty($seriesOf)){
                        $output = $output."
                            <tr>
                                <td><input onclick='checkbox()' class='checkbox' type='checkbox' value='$id'></td>
                                <td>$docNo</td>
                                <td>$title</td>
                                <td>$clientName</td>
                                <td>$secretaryName</td>
                                <td>$date</td>
                                <td class='text-danger'>$status</td>
                                <td><button onclick='setPayment($id,\"$title\",$amount,\"$clientName\")' class='bg-success text-light p-1' style='border:none;' data-bs-toggle='modal' data-bs-target='#single-payment-modal'>PayNow</button></td>
                            </tr>
                        ";
                    }
                }while($row = $query->fetch_assoc());
            
                return $output;
            }
            else{
                $output = $output."<tr><td class='dataTables-empty' colspan='8'>No entries found</td></tr>";
                return $output;
            }
        }

        function getTotalUnpaidDoc(){
            $sql = "SELECT * FROM `documents_tbl` WHERE `Status`='UNPAID' ORDER BY `Id` DESC";
            $query = $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $total = $query->num_rows;
            $completeDocs = 0;
            if($total){
                do{
                    $docNo = $row['Doc_No'];
                    $pageNo = $row['Page_No'];
                    $bookNo = $row['Book_No'];
                    $seriesOf = $row['Series_of'];
                    if(!empty($docNo) && !empty($pageNo) && !empty($bookNo) && !empty($seriesOf)){
                        $completeDocs++;
                    }
                }while($row = $query->fetch_assoc());
            }
            return $completeDocs;
        }

        function getDocumentData(){
            $id = $_POST['id'];
            $sql = "SELECT * FROM `documents_tbl` WHERE `Id`='$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            $row = $query->fetch_assoc();
            $output = array();
            foreach ($row as $key => $value) {
                $output[$key] = $value;
            }
            return json_encode($output);
        }

        function removeTemplate(){
            $id = $_POST['id'];
            $sql = "DELETE FROM `doc_templates_tbl` WHERE `Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            return "SUCCESS";
        }

        function removeDocument(){
            $id = $_POST['id'];
            $sql = "DELETE FROM `documents_tbl` WHERE `Id` = '$id'";
            $query = $this->connect->query($sql) or die($this->connect->error);
            return "SUCCESS";
        }
    
        function singleQuote($str){
    
            $input = $str;
            $output = "";
            $loopCount = 0;
            
            while ($loopCount < strlen($input)) {
                $output = str_replace ("'", "\'",  $input); 
                $loopCount++;
            }
            return $output;
            
        }
        
    }
?>